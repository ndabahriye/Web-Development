<?php include('include_header.php'); ?>


<!-- banner part start-->
<section class="banner_part" style="height:150px;">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-12 offset-lg-0">
<div class="banner_text">
<div class="banner_text_iner">

</div>
</div>
</div>
</div>
</div>
</section>



<!--::review_part end::-->
<div class="review_part padding_bottom" id="testimonial">
<div class="container">
<div class="row justify-content-center align-items-center">
<div class="col-lg-12">
<div class="section_tittle text-center">
<br><h2><i class="ti-anchor"></i> Available application</h2>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-12">





<div style="float:left; width:100%; background-color:#FFF; height:auto; color:#000; font-size:18px;">
<?php
if(isset($_GET['d']))
{
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_document.garbage_id, garbage_document.garbage_doc, garbage_document.garbage_description, garbage_document.garbage_date, garbage_document.garbage_status, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company, garbage_document WHERE garbage_company.w_comp_id=garbage_document.garbage_company_id AND garbage_document.garbage_id='".$_GET['d']."' ORDER BY garbage_document.garbage_id DESC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$garbage_id = $pos['garbage_id'];
$garbage_doc = "<img src=".$pos['garbage_doc'].">";
$garbage_doc_file = $pos['garbage_doc'];
$garbage_description = nl2br($pos['garbage_description']);
$garbage_date = $pos['garbage_date'];
$garbage_status = $pos['garbage_status'];

$w_comp_id = $pos['w_comp_id'];
$w_comp_name = strtoupper($pos['w_comp_name']);
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];

$edit="<a href='q?XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&edit_internship=".$garbage_id."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&login_now&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."' style='color:#fff; background-color:#006699; float:left; padding:0% 5% 0% 5%; margin-top:1%; border-radius:100px; font-weight:bold; font-size:18px;'><i class='ti-hand-point-right' style='color:#fff; font-weight:normal; font-size:18px;'></i> Apply here</a>";
?>

<?php echo "<b style='color:#006699; font-size:16px;'>Company: ".$w_comp_name."<br>Phone: ".$w_comp_phone."<br>Email: ".$w_comp_email."<br>Branches: ".$w_comp_branches."<br>Tin: ".$w_comp_tin."<br>Account: ".$w_comp_account; ?></b><br><br>
<?php echo $garbage_description."<br><br><i style='color:#006699; font-size:14px;'>".$garbage_date; ?></i><br>
<a href="q/<?php echo $garbage_doc_file; ?>" target="_blank" style="color:#006699; font-weight:bold; font-size:18px;"><br><i class='ti-download' style="color:#006699; font-weight:bold; font-size:14px;"></i> Download file</a><br><?php echo $edit; ?><br>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}







if(isset($_GET['mx']))
{
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_document.garbage_id, garbage_document.garbage_doc, garbage_document.garbage_description, garbage_document.garbage_date, garbage_document.garbage_status, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company, garbage_document WHERE garbage_company.w_comp_id=garbage_document.garbage_company_id ORDER BY garbage_document.garbage_id DESC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$garbage_id = $pos['garbage_id'];
$garbage_doc = "<img src=".$pos['garbage_doc'].">";
$garbage_doc_file = $pos['garbage_doc'];
$garbage_description = nl2br($pos['garbage_description']);
$garbage_date = $pos['garbage_date'];
$garbage_status = $pos['garbage_status'];

$w_comp_id = $pos['w_comp_id'];
$w_comp_name = strtoupper($pos['w_comp_name']);
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];

$edit="<a href='q?XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&edit_internship=".$garbage_id."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&login_now&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."' style='color:#fff; background-color:#006699; float:left; padding:0% 5% 0% 5%; margin-top:1%; border-radius:100px; font-weight:bold; font-size:18px;'><i class='ti-hand-point-right' style='color:#fff; font-weight:normal; font-size:18px;'></i> Apply here</a>";
?>

<?php echo "<b style='color:#006699; font-size:16px;'>Company: ".$w_comp_name."<br>Phone: ".$w_comp_phone."<br>Email: ".$w_comp_email."<br>Branches: ".$w_comp_branches."<br>Tin: ".$w_comp_tin."<br>Account: ".$w_comp_account; ?></b><br><br>
<?php echo $garbage_description."<br><br><i style='color:#006699; font-size:14px;'>".$garbage_date; ?></i><br>
<a href="q/<?php echo $garbage_doc_file; ?>" target="_blank" style="color:#006699; font-weight:bold; font-size:18px;"><br><i class='ti-download' style="color:#006699; font-weight:bold; font-size:14px;"></i> Download file</a><br><?php echo $edit; ?><br><hr>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}
?>
</div>


</div>
</div>
</div>
</div>


<?php include('include_js.php'); ?>
</body>
</html>
