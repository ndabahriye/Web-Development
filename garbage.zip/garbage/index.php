<?php include('include_header.php'); ?>


<!-- banner part start-->
<section class="banner_part">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-10 offset-lg-1">
<div class="banner_text">
<div class="banner_text_iner"><center>
<h1><i class="ti-hand-point-right"></i> Online Garbage Collection Management System <br>(O.G.C.M.S)</h1>
<h2><i class="ti-cloud-up"></i> Registration Process</h2>
<a href="q?<?php echo md5(date('is')); ?>&registration&title=REGISTRATION" style="color:#000; font-size:16px;" class="btn_1"><i class="ti-blackboard"></i> User /  Company / Organization Registration</a></center>
</div>
</div>
</div>
</div>
</div>
</section>




<!--::review_part end::-->
<div class="review_part padding_bottom" id="testimonial">
<div class="container">
<div class="row justify-content-center align-items-center">
<div class="col-lg-7">
<div class="section_tittle text-center">
<br><h2><i class="ti-anchor"></i> Stakeholders</h2>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-12">
<div class="review_part_text owl-carousel">


<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company ORDER BY garbage_company.w_comp_id DESC LIMIT 0,5");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];
?>
<div class="singler_eview_part">
<div class="client_info">
<?php echo $w_comp_logo; ?>
<h4><?php echo $w_comp_name; ?></h4>
<?php echo $w_comp_email; ?> - 
<?php echo $w_comp_phone; ?>
</div>
</div>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>


</div>
</div>
</div>
</div>
<img src="img/hand_writing.gif" class="animation_icon_3" style="width:auto; height:50px;" alt="">
</div>
<!--::review_part end::-->


<?php include('include_js.php'); ?>
</body>
</html>
