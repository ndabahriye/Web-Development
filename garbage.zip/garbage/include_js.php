<!-- footer part start-->
<footer class="footer-area">
<div class="container">
<div class="row justify-content-between">
<div class="col-sm-3 col-md-3 col-xl-3">
<div class="single-footer-widget footer_1">
<img src="img/icon.png" style="width:120px;"   alt="" />

<ul>
<li><a href="#"><i class="ti-agenda"></i> Final Year Project <?php echo date('Y'); ?></a></li>
<li><a href="#"><i class="ti-write"></i> University of Rwanda</a></li>
<li><a href="#"><i class="ti-signal"></i> Nyarugenge Campus</a></li>
<li><a href="#"><i class="ti-mouse-alt"></i> College of Science & Tech</a></li>
<li><a href="#"><i class="ti-blackboard"></i> School of ICT</a></li>
<li><a href="#"><i class="ti-rss-alt"></i> Depart. of Computer Science</a></li>
</ul>
<div class="social_icon">
<a href="#I.A.W.P.S"><i class="ti-facebook"></i></a>
<a href="#I.A.W.P.S"><i class="ti-twitter-alt"></i></a>
<a href="#I.A.W.P.S"><i class="ti-instagram"></i></a>
</div>
</div>
</div>
<div class="col-xl-3 col-sm-3 col-md-3">
<div class="single-footer-widget footer_2">
<h4><i class="ti-home"></i> Companies</h4>
<ul>
<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company ORDER BY garbage_company.w_comp_id DESC LIMIT 0,5");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='height:50px; border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];
?>
<li><a href="#"><?php echo $w_comp_logo; ?> <?php echo $w_comp_name; ?></a></li>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>

</ul>
</div>
</div>
<div class="col-xl-2 col-sm-6 col-md-2">
<div class="single-footer-widget footer_2">
<h4><i class="ti-blackboard"></i> Platforms</h4>
<ul>
<li><a href="#"><i class="ti-microsoft-alt"></i> Website</a></li>
<li><a href="#"><i class="ti-email"></i> Email</a></li>
<li><a href="#"><i class="ti-tablet"></i> Mobile App</a></li>
</ul>
</div>
</div>
<div class="col-xl-3 col-sm-6 col-md-3">
<div class="single-footer-widget footer_2">
<div class="single_contact_info">
<h3><i class="ti-view-list-alt"></i> Available Application</h3>

<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_document.garbage_id, garbage_document.garbage_doc, garbage_document.garbage_description, garbage_document.garbage_date, garbage_document.garbage_status, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company, garbage_document WHERE garbage_company.w_comp_id=garbage_document.garbage_company_id AND garbage_document.garbage_status=1 ORDER BY garbage_document.garbage_id DESC LIMIT 0,12");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$garbage_id = $pos['garbage_id'];
$garbage_doc_file = $pos['garbage_doc'];
$garbage_doc = "<img src='q/".$pos['garbage_doc']."' style='border-radius:100px;'>";
$garbage_description = $pos['garbage_description'];
$garbage_date = $pos['garbage_date'];
$garbage_status = $pos['garbage_status'];
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = strtoupper($pos['w_comp_name']);
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];

$details="qx?XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&d=".$garbage_id."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."";

?>
<a href="<?php echo $details; ?>" style="float:left; margin-bottom:2%; width:100%; color:#FFF; font-size:16px; font-weight:bold;"><i class="ti-pin-alt"></i>  In <?php echo $w_comp_name; ?></a><br />
<?php
}}
else
{ 
?>
<center><img src="q/images/sacrain.gif"/><br />
<a href="#" style="float:left; margin-bottom:2%; width:100%; color:#F00; font-size:16px; font-weight:bold;"><i class="ti-pin-alt"></i>  No application available</a></center>
<?php
}
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>


</div>
</div>
</div>
</div>
</div>
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="copyright_part_text text-center">
<div class="row">
<div class="col-lg-12">
<p class="footer-text m-0" style="color:#fff;">

Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | System developed by 3-CS Students


</p>
</div>
</div>
</div>
</div>
</div>
</div>

</footer>

<script src="js/jquery-1.12.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.magnific-popup.js"></script>
<script src="js/isotope.pkgd.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/custom.js"></script>