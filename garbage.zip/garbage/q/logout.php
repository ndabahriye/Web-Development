﻿<!DOCTYPE html>
<html lang="en"> 
<head>
<meta charset="UTF-8" />
<title> <?php  echo "Logout on ".date('h:i:s A'); ?> </title>
<link rel="shortcut icon" href="images/load-indicator.gif">
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta content="" name="description" />
<meta content="" name="author" />
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<body style="font-family:Arial, Helvetica, sans-serif;">

<?php
include_once('connection.php');
@session_start();
if(session_destroy()) // Destroying All Sessions
{	
?>
<center><br /><br /><br /><br />
<img src="images/load-indicator.gif" style="height:150px;" /><br />
<b ><font color="green" > Thank you !!! <br><?php  echo "Logout on ".date('h:i:s A'); ?></font></b>
</center>
<?php
echo '<meta http-equiv="refresh"'.'content="0; URL=../index?'.md5("ok").'">';
}

?>

</body>
</head>
</html>
