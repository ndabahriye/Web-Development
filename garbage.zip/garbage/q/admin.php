﻿<?php 
include('include_header.php');
include("connection.php");
include("session.php"); 

$top_aime="Done_by_IoT_Pioneerz_0785384384";
$top_start="admin?view_users=LIST%20OF%20USERS";
$top_success='<center><div class="card-body"><div class="alert alert-success" role="alert">
Done<br><img src="images/load-indicator.gif" style="height:80px;"></center>
</div></div><meta http-equiv="refresh"'.'content="0; URL=admin?panel_two">';
$top_failed='<center><div class="card-body"><div class="alert alert-danger" role="alert">
Done<br><img src="images/load-indicator.gif" style="height:80px;"></center>
</div></div><meta http-equiv="refresh"'.'content="0; URL=admin?panel_two">';

$_SESSION['member_id'];
$_SESSION['ProvinceID'];
$_SESSION['DistrictID'];
$_SESSION['Sector_ID'];
$_SESSION['Cell_ID'];
$_SESSION['position_id'];
$_SESSION['w_comp_id'];
$_SESSION['ProvinceName'];
$_SESSION['DistrictName'];
$_SESSION['SectorName'];
$_SESSION['CellName'];
$_SESSION['position_name'];
$_SESSION['w_comp_name'];
$_SESSION['w_comp_tin'];
$_SESSION['w_comp_logo'];
$_SESSION['w_comp_email'];
$_SESSION['w_comp_phone'];
$_SESSION['w_comp_account'];
$_SESSION['w_comp_moto'];
$_SESSION['w_comp_value'];
$_SESSION['w_comp_mission'];
$_SESSION['w_comp_branches'];
$_SESSION['first_name'];
$_SESSION['last_name'];
$_SESSION['telephone'];
$_SESSION['email'];
$_SESSION['national_id'];
$_SESSION['codes'];
$_SESSION['date_Time'];
$_SESSION['username'];
$_SESSION['password'];
$_SESSION['w_comp_status'];
$_SESSION['member_status'];
?>



<body class="animsition">
<div class="page-wrapper">
<!-- HEADER MOBILE-->
<header class="header-mobile d-block d-lg-none">
<div class="header-mobile__bar">
<div class="container-fluid">
<div class="header-mobile-inner">
<a class="logo" href="#">
<img src="../img/icon.png" style=" height:60px;" alt="IoT Pioneer" />

</a>
<button class="hamburger hamburger--slider" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</div>
<nav class="navbar-mobile">
<div class="container-fluid">
<ul class="navbar-mobile__list list-unstyled">

<ul class="list-unstyled navbar__list">
<li class="has-sub"><a class="js-arrow" href="<?php echo $top_start; ?>"><i class="fa fa-desktop"></i> Dashboard</a></li>
<li class="has-sub"><a class="js-arrow" href="admin?panel_two"><i class="fa fa-folder-open"></i> Control Panel</a></li>
<li class="has-sub"><a href="logout" onClick="return confirm('Confirm ?')"><i class="fa fa-lock"></i>&nbsp;Logout</a></li>
</ul>




<?php
$top_province_district = $DB_con->prepare("SELECT internship_province.ProvinceID, internship_province.ProvinceName, internship_district.DistrictID, internship_district.DistrictName  FROM internship_province, internship_district WHERE internship_province.ProvinceID=internship_district.ProvinceID ORDER BY internship_province.ProvinceID, internship_district.DistrictName ASC");
try {
$top_province_district->execute(array());
$top_row_province_district = $top_province_district->rowCount();
if ($top_row_province_district > 0)
{
$top_i=1;
while($top_p_d = $top_province_district->fetch(PDO::FETCH_ASSOC))
{
$top_ProvinceID = $top_p_d['ProvinceID'];
$top_DistrictID = $top_p_d['DistrictID'];
$top_ProvinceName = $top_p_d['ProvinceName'];
$top_DistrictName = $top_p_d['DistrictName'];
if($top_ProvinceName=='Iburengerazuba') {$top_ProvinceName_Kinya='Western';}
if($top_ProvinceName=='Iburasirazuba') {$top_ProvinceName_Kinya='Eastern';}
if($top_ProvinceName=='Amajyepfo') {$top_ProvinceName_Kinya='Southern';}
if($top_ProvinceName=='Amajyaruguru') {$top_ProvinceName_Kinya='Northern';}
if($top_ProvinceName=='Umujyi wa Kigali') {$top_ProvinceName_Kinya='Kigali City';}

//=========COUNT THE NUMBER
$top_sectors = $DB_con->prepare("SELECT COUNT(internship_members.member_id) FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_sectors.District_ID='".$top_DistrictID."'");
try {
$top_sectors->execute(array());
$top_row_sectors = $top_sectors->rowCount();
if ($top_row_sectors > 0)
{
$top_sector_array = $top_sectors->fetch(PDO::FETCH_ASSOC);
$top_count_no = $top_sector_array['COUNT(internship_members.member_id)'];
}
else{ }
}
catch (PDOException $top_ex)
{  $top_ex->getMessage();  }

?>

<ul class="list-unstyled navbar__list" style='font-weight:normal;text-transform:capitalize;'>
<li class="has-sub">
<a class="js-arrow" href="#"><i class="fa fa-list-ol"></i> <?php echo $top_ProvinceName_Kinya." &raquo; ".$top_DistrictName; ?> <span style='background-color:#e4e4e4; color:#000; font-size:12px; border-radius:20px;'>&nbsp;&nbsp;&nbsp; <?php echo $top_count_no; ?> &nbsp;&nbsp;&nbsp;</span></a>
<ul class="navbar-mobile-sub__list list-unstyled js-sub-list">








<?php
$top_sectors = $DB_con->prepare("SELECT internship_province.ProvinceID, internship_province.ProvinceName, internship_district.DistrictID, internship_district.DistrictName, internship_sectors.Sector_ID, internship_sectors.SectorName  FROM internship_province, internship_district, internship_sectors WHERE internship_province.ProvinceID=internship_district.ProvinceID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.DistrictID='".$top_DistrictID."' ORDER BY internship_province.ProvinceID, internship_district.DistrictName ASC");
try {
$top_sectors->execute(array());
$top_row_sectors = $top_sectors->rowCount();
if ($top_row_sectors > 0)
{
$top_sect=1;
while($top_sector_array = $top_sectors->fetch(PDO::FETCH_ASSOC))
{
$top_Sector_ID = $top_sector_array['Sector_ID'];
$top_SectorName = $top_sector_array['SectorName'];
$top_DistrictName = $top_sector_array['DistrictName'];
$top_ProvinceName = $top_sector_array['ProvinceName'];
if($top_ProvinceName=='Iburengerazuba') {$top_ProvinceName_Kinya='Western';}
if($top_ProvinceName=='Iburasirazuba') {$top_ProvinceName_Kinya='Eastern';}
if($top_ProvinceName=='Amajyepfo') {$top_ProvinceName_Kinya='Southern';}
if($top_ProvinceName=='Amajyaruguru') {$top_ProvinceName_Kinya='Northern';}
if($top_ProvinceName=='Umujyi wa Kigali') {$top_ProvinceName_Kinya='Kigali City';}

//=========COUNT THE NUMBER
$top_count_no = $DB_con->prepare("SELECT COUNT(internship_members.member_id) FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_sectors.Sector_ID='".$top_Sector_ID."'");
try {
$top_count_no->execute(array());
$top_row_count_no = $top_count_no->rowCount();
if ($top_row_count_no > 0)
{
$top_count_no_array = $top_count_no->fetch(PDO::FETCH_ASSOC);
$top_count_no_final = $top_count_no_array['COUNT(internship_members.member_id)'];
}
else{ }
}
catch (PDOException $top_ex)
{  $top_ex->getMessage();  }
//=========COUNT THE NUMBER END 

$top_link="<a href='admin?Sector_ID_Get=".$top_Sector_ID."&SectorName_Get=".$top_SectorName."&DistrictName_Get=".$top_DistrictName."&ProvinceName_Get=".$top_ProvinceName_Kinya."' title='".$top_aime."'>".$top_sect++.". ".$top_SectorName." <b style='background-color:#e4e4e4; color:#000; font-size:12px; border-radius:20px;'>&nbsp;&nbsp;&nbsp;".$top_count_no_final."&nbsp;&nbsp;&nbsp;</b></a>";
?>
<li style='font-weight:normal;text-transform:capitalize;'><?php echo $top_link; ?></li>
<?php
}}
else{ }
}
catch (PDOException $top_ex)
{  $top_ex->getMessage();  }
?>




</ul>
</li>
</ul>

<?php
}}
else{ }
}
catch (PDOException $top_ex)
{  $top_ex->getMessage();  }
?>
</ul>

</div>
</nav>
</header>
<!-- END HEADER MOBILE-->

<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
<div class="logo">
<center><a href="#">
<img src="../img/icon.png" style=" height:50px; " alt="IoT Pioneer" /> 
</a></center>
</div>
<div class="menu-sidebar__content js-scrollbar1">
<nav>

<ul class="list-unstyled">
<li class="has-sub"><a class="js-arrow" style="color:#000; margin:10% 0% 0% 3%;" href="<?php echo $top_start; ?>"><i class="fa fa-desktop"></i> Dashboard</a></li>
<li class="has-sub"><a class="js-arrow" style="color:#000; margin:4% 0% 0% 3%;" href="admin?panel_two"><i class="fa fa-folder-open"></i> Control Panel</a></li>
<li class="has-sub"><a href="logout" style="color:#000; margin:4% 0% 0% 3%;" onClick="return confirm('Confirm ?')"><i class="fa fa-lock"></i> Logout</a></li>
</ul>

<?php
$province_district = $DB_con->prepare("SELECT internship_province.ProvinceID, internship_province.ProvinceName, internship_district.DistrictID, internship_district.DistrictName  FROM internship_province, internship_district WHERE internship_province.ProvinceID=internship_district.ProvinceID ORDER BY internship_province.ProvinceID, internship_district.DistrictName ASC");
try {
$province_district->execute(array());
$row_province_district = $province_district->rowCount();
if ($row_province_district > 0)
{
$i=1;
while($p_d = $province_district->fetch(PDO::FETCH_ASSOC))
{
$ProvinceID = $p_d['ProvinceID'];
$DistrictID = $p_d['DistrictID'];
$ProvinceName = $p_d['ProvinceName'];
$DistrictName = $p_d['DistrictName'];

//=========COUNT THE NUMBER
$count_no = $DB_con->prepare("SELECT COUNT(internship_members.member_id) FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_district.DistrictID='".$DistrictID."'");
try {
$count_no->execute(array());
$row_count_no = $count_no->rowCount();
if ($row_count_no > 0)
{
$count_no_array = $count_no->fetch(PDO::FETCH_ASSOC);
$count_no_final = $count_no_array['COUNT(internship_members.member_id)'];
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
//=========COUNT THE NUMBER END 

if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
?>

<ul class="list-unstyled navbar__list" style='font-weight:normal;text-transform:capitalize;'>
<li class="has-sub">
<a class="js-arrow" href="#" style="color:#000; margin:5% 0% 0% 3%;"><i class="fa fa-list-ol"></i> <?php echo $ProvinceName_Kinya." &raquo; ".$DistrictName; ?> <span style='background-color:#e4e4e4; color:#000; font-size:12px; border-radius:20px;'>&nbsp;&nbsp;&nbsp; <?php echo $count_no_final; ?> &nbsp;&nbsp;&nbsp;</span></a>
<ul class="list-unstyled navbar__sub-list js-sub-list">




<?php
$sectors = $DB_con->prepare("SELECT internship_province.ProvinceID, internship_province.ProvinceName, internship_district.DistrictID, internship_district.DistrictName, internship_sectors.Sector_ID, internship_sectors.SectorName  FROM internship_province, internship_district, internship_sectors WHERE internship_province.ProvinceID=internship_district.ProvinceID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.DistrictID='".$DistrictID."' ORDER BY internship_province.ProvinceID, internship_district.DistrictName ASC");
try {
$sectors->execute(array());
$row_sectors = $sectors->rowCount();
if ($row_sectors > 0)
{
$sect=1;
while($sector_array = $sectors->fetch(PDO::FETCH_ASSOC))
{
$Sector_ID = $sector_array['Sector_ID'];
$SectorName = $sector_array['SectorName'];
$DistrictName = $sector_array['DistrictName'];
$ProvinceName = $sector_array['ProvinceName'];

//=========COUNT THE NUMBER
$count_no = $DB_con->prepare("SELECT COUNT(internship_members.member_id) FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_sectors.Sector_ID='".$Sector_ID."'");
try {
$count_no->execute(array());
$row_count_no = $count_no->rowCount();
if ($row_count_no > 0)
{
$count_no_array = $count_no->fetch(PDO::FETCH_ASSOC);
$count_no_final = $count_no_array['COUNT(internship_members.member_id)'];
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
//=========COUNT THE NUMBER END

if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
$link="<a href='admin?Sector_ID_Get=".$Sector_ID."&SectorName_Get=".$SectorName."&DistrictName_Get=".$DistrictName."&ProvinceName_Get=".$ProvinceName_Kinya."' title='".$top_aime."'>".$sect++.". ".$SectorName." <b style='background-color:#e4e4e4; color:#000; font-size:12px; border-radius:20px;'>&nbsp;&nbsp;&nbsp; ".$count_no_final." &nbsp;&nbsp;&nbsp;</b></a>";
?>
<li style='font-weight:normal;text-transform:capitalize;'><?php echo $link; ?></li>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>


</ul>
</li>
</ul>

<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>


</nav>
</div>
</aside>
<!-- END MENU SIDEBAR-->

<!-- PAGE CONTAINER-->
<div class="page-container">
<!-- HEADER DESKTOP-->
<header class="header-desktop">
<div class="section__content section__content--p30">
<div class="container-fluid">
<div class="header-wrap">


<!-- SEARCHING -->
<div class="search-box">
<input type="text" autofocus autocomplete="off"  required placeholder="Search user..." />
<div class="result"></div>
</div>



</div>
</div>
</div>
</header>
<!-- END HEADER DESKTOP-->

<!-- MAIN CONTENT-->
<div class="main-content">
<div class="section__content section__content--p30">
<div class="container-fluid">

<body onload="startTime()">
<div id="txt" style="font-family:Digital-7 Mono; font-size:24px; color:#000;"></div>
</body>

<div class="row">
<div class="col-lg-12">
<div class="card">

<?php

//====================================================================================SAVE POSITION
if(isset($_POST['save_position']))
{
$position_name=$_POST['position_name'];
$save_position= $DB_con->prepare("INSERT INTO internship_position (position_id, position_name)   VALUES(?,?)");
$save_position->execute(array('',$position_name));
if($save_position) { echo $top_success;  }
else  {  echo $top_failed;  }
}

//====================================================================================SAVE UPDATE POSITION
if(isset($_POST['save_update_position']))
{
$position_id=$_POST['position_id'];
$position_name=$_POST['position_name'];
$sql = "UPDATE internship_position SET position_name = :position_name  WHERE internship_position.position_id = :position_id";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':position_id', $position_id, PDO::PARAM_INT);
$stmt->bindParam(':position_name', $position_name, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}




//====================================================================================SAVE UPDATE PRICE
if(isset($_POST['save_unit_price_edit']))
{
$price_id=$_POST['price_id'];
$price=$_POST['price'];
$cate_id=$_POST['cate_id'];
$date=date('l d-m-Y h:i:s A');

$sql = "UPDATE internship_price_per_unit SET w_p_cate_id = :cate_id, w_p_p_u_price = :price, w_p_date_time = :date WHERE internship_price_per_unit.w_p_p_u_id = :price_id";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':price_id', $price_id, PDO::PARAM_INT);
$stmt->bindParam(':price', $price, PDO::PARAM_INT);
$stmt->bindParam(':cate_id', $cate_id, PDO::PARAM_INT);
$stmt->bindParam(':date', $date, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}





if(isset($_GET['edit_position']))
{
$edit_pos_id=$_GET['edit_position'];
$edit_position_name=$_GET['edit_position_name'];
?>
<div class="col-lg-4">
<div class="login-form">
<label>UPDATE THIS RECORD</label>
<form action="admin" method="POST" enctype="multipart/form-data">
<div class="form-group">
<input type="hidden" required name="position_id" value="<?php echo $edit_pos_id; ?>">
<input class="au-input au-input--full" type="text" required name="position_name" value="<?php echo $edit_position_name; ?>" autofocus>
</div>
<button class="au-btn au-btn--block au-btn--green m-b-20" name="save_update_position" onClick="return confirm('Confirm ?')" type="submit"><i class="fa fa-save"></i> Accept | Save</button>
</form>
</div>
</div>
<?php
}


if(isset($_POST['save_company']))
{
$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["w_comp_logo"]["name"]);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
move_uploaded_file($_FILES["w_comp_logo"]["tmp_name"], $target_file);
$target_file="images/".basename($_FILES["w_comp_logo"]["name"]);

$w_comp_name=htmlspecialchars($_POST['w_comp_name']);
$w_comp_tin=$_POST['w_comp_tin'];
$w_comp_email=strtolower($_POST['w_comp_email']);
$w_comp_phone=$_POST['w_comp_phone'];
$w_comp_account=$_POST['w_comp_account'];
$w_comp_moto=htmlspecialchars($_POST['w_comp_moto']);
$w_comp_value=htmlspecialchars($_POST['w_comp_value']);
$w_comp_mission=htmlspecialchars($_POST['w_comp_mission']);
$w_comp_branches=htmlspecialchars($_POST['w_comp_branches']);
$w_comp_status=1;

$save_company = $DB_con->prepare("INSERT INTO internship_company (w_comp_id, w_comp_name, w_comp_tin, w_comp_logo, w_comp_email, w_comp_phone, w_comp_account, w_comp_moto, w_comp_value, w_comp_mission, w_comp_branches, w_comp_status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");  
$save_company->execute(array('',$w_comp_name,$w_comp_tin,$target_file,$w_comp_email,$w_comp_phone,$w_comp_account,$w_comp_moto,$w_comp_value,$w_comp_mission,$w_comp_branches,$w_comp_status));
if($save_company) { echo $top_success;  }
else  {  echo $top_failed;  }
}





if(isset($_POST['save_user']))
{
$position_id=$_POST['position_id'];
$company_id=$_POST['company_id'];
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];
$cell_id=$_POST['cell_id'];
$national_id=$_POST['national_id'];
$codes=date('is');
$date_Time=date('d-m-Y');
$member_status=1;
$username=strtolower($email);
$password=md5('12345');
$username_not_encrypted=strtolower($email);
$password_not_encrypted=12345;

$save_stmt = $DB_con->prepare("INSERT INTO internship_members (member_id, position_id, company_id, first_name, last_name, telephone, email, cell_id, national_id, codes, date_Time, member_status, username, password) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");  
$save_stmt->execute(array('',$position_id,$company_id,$first_name,$last_name,$telephone,$email,$cell_id,$national_id,$codes,$date_Time,$member_status,$username,$password));

$passwordx=$password_not_encrypted;
$usernamex=$username_not_encrypted;
$fromName="REGISTRATION PROCESS";
$message="Welcome ".@$first_name." ".@$last_name.", REGISTRATION PROCESS is well done. Registration date is (".date('l d/m/Y h:i:s A').")\n\n Username: ".$usernamex."\n\n Password: ".$passwordx."\n\nMore details, visit www.internship.rw";
$send_to_mail=htmlspecialchars($_POST['email']);
$messages=wordwrap($message, 100, "\r\n");
@mail($send_to_mail, $fromName, $messages);

echo '<center><div class="card-body"><div class="alert alert-success" role="alert">
Done<br><hr>Username: '.$username_not_encrypted.'<br>Password: '.$password_not_encrypted.'<br><hr><br><img src="images/load-indicator.gif" style="height:80px;"></center><meta http-equiv="refresh"'.'content="5; URL=admin?panel_two">';
}










if(isset($_POST['save_user_counter_unit']))
{
$member_id=htmlspecialchars($_POST['member_id']);
$w_p_p_u_id=htmlspecialchars($_POST['w_p_p_u_id']);
$unit_used=htmlspecialchars($_POST['unit_used']);
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-refresh'></i> Processing...</span><a href="admin?panel_two" style="float:right;"><i class="fa fa-plus"></i> Add user</a><br></h4>
</div>
<?php
$position_view = $DB_con->prepare("SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_members.member_id='".$_POST['member_id']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
$pos = $position_view->fetch(PDO::FETCH_ASSOC);

$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$CellNamex = $ProvinceName." - ".$pos['DistrictName']." - ".$pos['SectorName']." - ".$pos['CellName'];
?>
<div class="container">
<div class="card-body card-block">
<div class="col col-md-7">

<form action="admin" enctype="multipart/form-data" method="POST" class="form-horizontal">
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-signal"></i></div>
<input type="text" value="<?php echo $CellNamex; ?>" readonly class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-anchor"></i></div>
<input type="text" value="<?php echo $position_name." - ".$w_comp_name; ?>" readonly class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" value="<?php echo $first_name." ".$last_name; ?>" readonly class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
<input type="text" value="<?php echo $telephone." - ".$email; ?>" readonly class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="text" value="<?php echo $national_id; ?>" readonly class="form-control">
</div></div>

<?php //=========COUNTER
$count_no = $DB_con->prepare("SELECT internship_counter.w_c_id, internship_counter.w_c_no,internship_category.w_cat_id, internship_counter.w_c_status, internship_category.w_cat_name, internship_members.first_name, internship_price_per_unit.w_p_p_u_price, internship_price_per_unit.w_p_p_u_id FROM internship_counter, internship_members, internship_category, internship_price_per_unit WHERE internship_counter.w_c_user_id=internship_members.member_id AND internship_category.w_cat_id=internship_counter.w_c_category AND internship_price_per_unit.w_p_cate_id=internship_category.w_cat_id AND internship_counter.w_c_user_id='".$member_id."' AND internship_price_per_unit.w_p_p_u_id='".$w_p_p_u_id."'");
try {
$count_no->execute(array());
$row_count_no = $count_no->rowCount();
if ($row_count_no > 0)
{
$count_no_array = $count_no->fetch(PDO::FETCH_ASSOC);
$w_c_id = $count_no_array['w_c_id'];
$w_c_no = $count_no_array['w_c_no'];
$w_cat_id = $count_no_array['w_cat_id'];
$w_cat_name = $count_no_array['w_cat_name'];
$w_p_p_u_id = $count_no_array['w_p_p_u_id'];
$w_p_p_u_price = $count_no_array['w_p_p_u_price'];
?>

<div class="row form-group"><div class="input-group">
<input type="hidden" name="member_id" value="<?php echo $member_id; ?>">
<input type="hidden" name="w_cat_id" value="<?php echo $w_cat_id; ?>">
<input type="hidden" name="w_p_p_u_id" value="<?php echo $w_p_p_u_id; ?>">
<input type="hidden" name="w_p_p_u_price" value="<?php echo $w_p_p_u_price; ?>">
<input type="hidden" name="unit_used" value="<?php echo $unit_used; ?>" readonly class="form-control">
<input type="text" value="<?php echo "(".$unit_used." m3  x ".$w_p_p_u_price." Rwf) / 1 m3"; ?>" readonly class="form-control">
<input type="text"  value="<?php echo $w_p_p_u_price*$unit_used; ?> Rwf" readonly class="form-control">
<input type="hidden" name="total_price" value="<?php echo $w_p_p_u_price*$unit_used; ?>">
</div></div>

<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
//=========COUNTER NUMBER END
?>


<div class="row form-group"><div class="input-group"><div class="input-group-addon">
<button type="submit" name="save_user_counter_unit_now" onClick="return confirm('Confirm ?')" class="btn btn-success btn-sm"><i class="fa fa-location-arrow"></i> Confirm and send to <?php echo $last_name; ?></button>
</div></div>
</form>
</div>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}



?>
</div>











<?php
if(isset($_GET['panel_two']))
{
@$Sector_ID_Get=$_GET['Sector_ID_Get'];
@$SectorName_Get=$_GET['SectorName_Get'];
@$DistrictName_Get=$_GET['DistrictName_Get'];
@$ProvinceName_Get=$_GET['ProvinceName_Get'];

?>
<div class="card">
<div class="card-body">
<div class="default-tab">
<nav>
<div class="nav nav-tabs" id="nav-tab" role="tablist">

<a class="nav-item nav-link active" id="nav-user-tab" data-toggle="tab" href="#nav-user" role="tab" aria-controls="nav-user"
aria-selected="true"><i class='fa fa-user'></i> User</a>

<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile"
aria-selected="false"><i class='fa fa-folder'></i> Profile</a>

<a class="nav-item nav-link" id="nav-position-tab" data-toggle="tab" href="#nav-position" role="tab" aria-controls="nav-position"
aria-selected="false"><i class='fa fa-folder-open'></i> Position</a>

<a class="nav-item nav-link" id="nav-company-tab" data-toggle="tab" href="#nav-company" role="tab" aria-controls="nav-company"
aria-selected="false"><i class='fa fa-folder-open'></i> Company</a>

</div>
</nav>




<div class="tab-content pl-3 pt-2" id="nav-tabContent">
<div class="tab-pane fade show active" id="nav-user" role="tabpanel" aria-labelledby="nav-user-tab"  style='font-family: arial;  color:#000;'>
<b>USER SETTINGS<span><a href="admin?view_users=LIST OF USERS" style="float:right;"><i class="fa fa-list-ul"></i> View users</a></span></b><br>
<div class="container">
<div class="card-body card-block">
<div class="col col-md-9">
<form action="admin" enctype="multipart/form-data" method="POST" class="form-horizontal">
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-location-arrow"></i></div>
<select name="cell_id" style="text-transform:capitalize;" class="form-control" required>
<option value=" ">Please select address</option>
<?php
$stmt_view = $DB_con->prepare("SELECT internship_cells.Cell_ID, internship_cells.CellName, internship_sectors.SectorName, internship_district.DistrictName, internship_province.ProvinceName FROM internship_cells, internship_sectors, internship_district, internship_province WHERE internship_sectors.Sector_ID=internship_cells.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_province.ProvinceID=internship_district.ProvinceID ORDER BY internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$Cell_ID = $stmt['Cell_ID'];
$ProvinceName = $stmt['ProvinceName'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
$CellName = $ProvinceName_Kinya." - ".$stmt['DistrictName']." - ".$stmt['SectorName']." - ".$stmt['CellName'];
echo '<option value="'.$Cell_ID.'">'.$CellName.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-anchor"></i></div>
<select name="position_id" class="form-control" required>
<option value=" ">Please select position</option>
<?php
$stmt_view = $DB_con->prepare("SELECT internship_position.position_id, internship_position.position_name FROM internship_position ORDER BY internship_position.position_name ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$position_id = $stmt['position_id'];
$position_name = $stmt['position_name'];
echo '<option value="'.$position_id.'">'.$position_name.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-bar-chart-o"></i></div>
<select name="company_id" class="form-control" required>
<option value=" ">Please select company</option>
<?php
$stmt_view = $DB_con->prepare("SELECT internship_company.w_comp_id, internship_company.w_comp_name FROM internship_company ORDER BY internship_company.w_comp_name ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$w_comp_id = $stmt['w_comp_id'];
$w_comp_name = $stmt['w_comp_name'];
echo '<option value="'.$w_comp_id.'">'.$w_comp_name.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="first_name" placeholder="First name" pattern="[A-Z']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="last_name" placeholder="Last name" pattern="[A-Z a-z ']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
<input type="text" name="telephone" placeholder="+250 - - - - -" pattern="[+0-9]+" maxlength="13" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-envelope"></i></div>
<input type="email" name="email" placeholder="Email" class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="text" name="national_id" placeholder="National ID No" pattern="[0-9]+" maxlength="16" class="form-control" required>
</div></div>
<button type="submit" name="save_user" class="btn btn-success btn-sm"><i class="fa fa-dot-circle-o"></i> Save user</button>
<button type="reset" class="btn btn-danger btn-sm"><i class="fa fa-ban"></i> Cancel</button>
</form>
</div>
</div>
</div>

</div>

<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"  style='font-family: arial;  color:#000;'>
<b>MY PROFILE </b><br>

<?php
$position_view = $DB_con->prepare("SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_members.member_id='".$_SESSION['member_id']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>#</th><th>Name</th><th>Address</th><th>Company</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}

if($member_status==1)   { $decision='<a href="admin?deny_member='.$member_id.'"><i class="fa fa-trash"></i> deny</a>';}
else   { $decision='<a href="admin?restore_member='.$member_id.'"><i class="fa fa-refresh"></i> restore</a>';}
$edit='<a href="admin?edit_member='.$member_id.'"><i class="fa fa-edit"></i> edit</a>';
?>
<tr>
<td><?php echo $comp_count."<br>".$edit."<br>".$decision; ?></td>
<td><?php echo $position_name."<br>".$first_name." ".$last_name."<br><a href='tel:".$telephone."'><i class='fa fa-phone'></i> ".$telephone."</a><br><a href='mailto:".$email."'><i class='fa fa-envelope'></i> ".$email."</a>"; ?></td>
<td style="text-transform:capitalize;">P: <?php echo $ProvinceName_Kinya."<br>D: ".$DistrictName."<br>S: ".$SectorName."<br>C: ".$CellName; ?></td>
<td><?php echo $w_comp_name."<br>".$w_comp_email."<br>".$w_comp_phone."<br>TIN: ".$w_comp_tin."<br>Bank: ".$w_comp_account; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>

</div>

<div class="tab-pane fade" id="nav-position" role="tabpanel" aria-labelledby="nav-position-tab"  style='font-family: arial;  color:#000;'>
<b>ACCESS LEVELS </b><br>


<div class="header-button" style="float:right;">
<div class="account-wrap">
<div class="account-item clearfix js-item-menu">
<div class="content">
<a class="js-acc-btn" href="#"><i class="fa fa-cogs"></i> Settings</a>
</div>
<div class="account-dropdown js-dropdown">
<div class="account-dropdown__body">
<div class="container">
<div class="login-form">
<b>NEW POSITION</b><br>
<form action="admin" method="POST" enctype="multipart/form-data">
<div class="form-group">
<input class="au-input au-input--full" type="text" required name="position_name" placeholder="Position name" autofocus>
</div>
<button class="au-btn au-btn--block au-btn--green m-b-20" name="save_position" onClick="return confirm('Confirm ?')" type="submit"><i class="fa fa-check"></i> Accept | Save</button>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<?php
$position_view = $DB_con->prepare("SELECT internship_position.position_id, internship_position.position_name FROM internship_position ORDER BY internship_position.position_name ASC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<table class="table table-borderless table-striped table-earning">
<thead><tr><th>#</th><th>Position</th><th>Edit</th><th>Delete</th></tr></thead>
<tbody>
<?php
$pos_account=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$pos_account++;
$position_id = $pos['position_id'];
$position_name = $pos['position_name'];
?>
<tr>
<td><?php echo $pos_account; ?></td>
<td><?php echo $position_name; ?></td>
<td><a href="admin?edit_position=<?php echo $position_id; ?>&edit_position_name=<?php echo $position_name; ?>&panel_one"><i class="fa fa-edit"></i> edit</a></td>
<td><a href="admin?delete_position=<?php echo $position_id; ?>&panel_one"><i class="fa fa-trash"></i> delete</a></td>
</tr>
<?php
}
?>
</tbody>
</table>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>




<div class="tab-pane fade" id="nav-company" role="tabpanel" aria-labelledby="nav-company-tab"  style='font-family: arial;  color:#000;'>
<b>COMPANY SETTING <span><a href="admin?view_companies=LIST OF COMPANIES" style="float:right;"><i class="fa fa-list-ul"></i> View companies</a></span></b><br><br>
<div class="container">
<div class="col-lg-6">
<div class="login-form">
<div class="form-group">

<form action="admin" method="POST" enctype="multipart/form-data">
<label> <input class="au-input au-input--full" type="text" name="w_comp_name" placeholder="Company nane..." autofocus required> </label>
<label> <input class="au-input au-input--full" type="text" name="w_comp_tin" placeholder="Company TIN..." pattern="[0-9]+" maxlength="9" required> </label><label> Upload logo</label>
<label> <input class="au-input au-input--full" type="file" name="w_comp_logo" required> </label>
<label> <input class="au-input au-input--full" type="email" name="w_comp_email" placeholder="Email" required></label>
<label> <input class="au-input au-input--full" type="text" name="w_comp_phone" placeholder="Phone" pattern="[+0-9]+" maxlength="13"> </label>
<label> <input class="au-input au-input--full" type="text" name="w_comp_account" placeholder="Company account" required> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_moto" placeholder="Company moto..." required></textarea> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_value" placeholder="Company value..." required></textarea> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_mission" placeholder="Company mission..." required></textarea> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_branches" placeholder="Company branches..." required></textarea> </label>

<label><button name="save_company" type="submit" class="btn btn-success" onClick="return confirm('Confirm')"> <i class="fa fa-upload"></i>&nbsp; Save Company Details</button></label>
<label> <button type="reset" class="btn btn-danger" onClick="return confirm('Confirm')"><i class="fa fa-trash"></i>&nbsp; Cancel and Start Again</button></label>
</form>
</div>
</div>
</div>
</div>
</div>



</div>
</div>
</div>
</div>
<?php
}



if(isset($_GET['edit_company_logo']))
{
$position_view = $DB_con->prepare("SELECT internship_company.w_comp_id, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status FROM internship_company WHERE internship_company.w_comp_id='".$_GET['edit_company_logo']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
$pos = $position_view->fetch(PDO::FETCH_ASSOC);

$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>

<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-upload'></i> UPDATE LOGO </span></h4><br>
<div class="container"><div class="col-lg-6"><div class="login-form"><div class="form-group">
<form action="admin" method="POST" enctype="multipart/form-data">
<input type="hidden" name="w_comp_id" value="<?php echo @$w_comp_id; ?>"> 
<label><?php echo @$w_comp_logo; ?></label>
<label> Upload new logo</label>
<label><input class="au-input au-input--full" type="file" name="w_comp_logo_update" required> </label>
<label><button name="save_company_update_logo" type="submit" class="btn btn-success" onClick="return confirm('Confirm')"> <i class="fa fa-upload"></i>&nbsp; Save Company Updated</button></label>
</form>
</div></div></div></div></div>  
<?php
}






if(isset($_POST['save_company_update_logo']))
{
$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["w_comp_logo_update"]["name"]);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
move_uploaded_file($_FILES["w_comp_logo_update"]["tmp_name"], $target_file);
$target_file="images/".basename($_FILES["w_comp_logo_update"]["name"]);

$w_comp_id=$_POST['w_comp_id'];
$upload_logo=$target_file;
$sql = "UPDATE internship_company SET w_comp_logo = :upload_logo WHERE internship_company.w_comp_id = :w_comp_id";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':upload_logo', $upload_logo, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_id', $w_comp_id, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}


if(isset($_POST['save_company_details']))
{
$w_comp_id = $_POST['w_comp_id'];
$w_comp_name = $_POST['w_comp_name'];
$w_comp_tin = $_POST['w_comp_tin'];
$w_comp_email = $_POST['w_comp_email'];
$w_comp_phone = $_POST['w_comp_phone'];
$w_comp_account = $_POST['w_comp_account'];
$w_comp_moto = $_POST['w_comp_moto'];
$w_comp_value = $_POST['w_comp_value'];
$w_comp_mission = $_POST['w_comp_mission'];
$w_comp_branches = $_POST['w_comp_branches'];

$sql = "UPDATE internship_company SET w_comp_name = :w_comp_name, w_comp_tin = :w_comp_tin, w_comp_email = :w_comp_email, w_comp_phone = :w_comp_phone, w_comp_account = :w_comp_account, w_comp_moto = :w_comp_moto, w_comp_value = :w_comp_value, w_comp_mission = :w_comp_mission, w_comp_branches = :w_comp_branches WHERE internship_company.w_comp_id = :w_comp_id";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':w_comp_id', $w_comp_id, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_name', $w_comp_name, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_tin', $w_comp_tin, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_email', $w_comp_email, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_phone', $w_comp_phone, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_account', $w_comp_account, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_moto', $w_comp_moto, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_value', $w_comp_value, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_mission', $w_comp_mission, PDO::PARAM_INT);
$stmt->bindParam(':w_comp_branches', $w_comp_branches, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}


if(isset($_GET['edit_company']))
{
$position_view = $DB_con->prepare("SELECT internship_company.w_comp_id, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status FROM internship_company WHERE internship_company.w_comp_id='".$_GET['edit_company']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
$pos = $position_view->fetch(PDO::FETCH_ASSOC);

$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = $pos['w_comp_moto'];
$w_comp_value = $pos['w_comp_value'];
$w_comp_mission = $pos['w_comp_mission'];
$w_comp_branches = $pos['w_comp_branches'];
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-upload'></i> UPDATE COMPANY DETAILS </span>
<span style="float:right;"><a href="admin?view_companies=LIST%20OF%20COMPANIES"><i class="fa fa-list"></i> Back</a></span></h4><br>


<div class="container">
<div class="col-lg-6">
<div class="login-form">
<div class="form-group">

<form action="admin" method="POST" enctype="multipart/form-data">
<input class="au-input au-input--full" type="hidden" name="w_comp_id" value="<?php echo $w_comp_id; ?>">
<label> <input class="au-input au-input--full" type="text" name="w_comp_name" value="<?php echo $w_comp_name; ?>" autofocus required> </label>
<label> <input class="au-input au-input--full" type="text" name="w_comp_tin" value="<?php echo $w_comp_tin; ?>" pattern="[0-9]+" maxlength="9" required> </label>
<label> <input class="au-input au-input--full" type="email" name="w_comp_email" value="<?php echo $w_comp_email; ?>"  required></label>
<label> <input class="au-input au-input--full" type="text" name="w_comp_phone" value="<?php echo $w_comp_phone; ?>"  pattern="[+0-9]+" maxlength="13"> </label>
<label> <input class="au-input au-input--full" type="text" name="w_comp_account" value="<?php echo $w_comp_account; ?>"  required> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_moto" required><?php echo $w_comp_moto; ?></textarea> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_value" required><?php echo $w_comp_value; ?></textarea> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_mission" required><?php echo $w_comp_mission; ?></textarea> </label>
<label> <textarea class="au-input au-input--full" type="text" name="w_comp_branches" required><?php echo $w_comp_branches; ?></textarea> </label>
<label><button name="save_company_details" type="submit" class="btn btn-success" onClick="return confirm('Confirm')"> <i class="fa fa-upload"></i>&nbsp; Save Company Details</button></label>
</form>
</div>
</div>
</div>
</div>	

</div>  
<?php
}




if(isset($_GET['deny_company']))
{
$w_comp_id=$_GET['deny_company'];
$sql = "UPDATE internship_company SET w_comp_status = 0 WHERE internship_company.w_comp_id = :w_comp_id";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':w_comp_id', $w_comp_id, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}



if(isset($_GET['restore_company']))
{
$w_comp_id=$_GET['restore_company'];
$sql = "UPDATE internship_company SET w_comp_status = 1 WHERE internship_company.w_comp_id = :w_comp_id";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':w_comp_id', $w_comp_id, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}

	  
	  
if(isset($_GET['view_companies']))
{
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-list-ul'></i> <?php echo @$_GET['view_companies']; ?>  <br></span></h4>
</div>
<?php
$position_view = $DB_con->prepare("SELECT internship_company.w_comp_id, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status FROM internship_company ORDER BY internship_company.w_comp_name ASC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>#</th><th>Name</th><th>Contact</th><th>Moto</th><th>Value</th><th>Mission</th><th>Branches</th><th>Edit</th><th>Status</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo']." style='height:50px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];
if($w_comp_status==1)   { $decision='<a href="admin?deny_company='.$w_comp_id.'"><i class="fa fa-trash"></i> deny</a>';}
else   { $decision='<a href="admin?restore_company='.$w_comp_id.'"><i class="fa fa-refresh"></i> restore</a>';}
$edit='<a href="admin?edit_company='.$w_comp_id.'"><i class="fa fa-edit"></i> edit</a>';
$change_logo='<a href="admin?edit_company_logo='.$w_comp_id.'"><i class="fa fa-upload"></i> update logo</a>';
?>
<tr>
<td><?php echo $comp_count; ?></td>
<td><?php echo $w_comp_name."<br>".$w_comp_logo."<br>".$change_logo; ?></td>
<td><?php echo $w_comp_email."<br>".$w_comp_phone."<br>TIN: ".$w_comp_tin."<br>Bank: ".$w_comp_account; ?></td>
<td><?php echo $w_comp_moto; ?></td>
<td><?php echo $w_comp_value; ?></td>
<td><?php echo $w_comp_mission; ?></td>
<td><?php echo $w_comp_branches; ?></td>
<td><?php echo $edit; ?></td>
<td><?php echo $decision; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}






if(isset($_GET['deny_member']))
{
$deny_member=$_GET['deny_member'];
$sql = "UPDATE internship_members SET member_status = 0 WHERE internship_members.member_id = :deny_member";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':deny_member', $deny_member, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}


if(isset($_GET['restore_member']))
{
$restore_member=$_GET['restore_member'];
$sql = "UPDATE internship_members SET member_status = 1 WHERE internship_members.member_id = :restore_member";
$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':restore_member', $restore_member, PDO::PARAM_INT);
$stmt->execute();
if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}







if(isset($_GET['view_users']))
{
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-list-ul'></i> <?php echo @$_GET['view_users']; ?></span><br></h4>
</div>
<?php
$position_view = $DB_con->prepare("SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID ORDER BY internship_position.position_id ASC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>#</th><th>Name</th><th>Address</th><th>Company</th><th>Edit</th><th>Status</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}

if($member_status==1)   { $decision='<a href="admin?deny_member='.$member_id.'"><i class="fa fa-trash"></i> deny</a>';}
else   { $decision='<a href="admin?restore_member='.$member_id.'"><i class="fa fa-refresh"></i> restore</a>';}
$edit='<a href="admin?edit_member='.$member_id.'"><i class="fa fa-edit"></i> edit</a>';
?>
<tr>
<td><?php echo $comp_count."<br>".$edit."<br>".$decision; ?></td>
<td><?php echo $position_name."<br>".$first_name." ".$last_name."<br><a href='tel:".$telephone."'><i class='fa fa-phone'></i> ".$telephone."</a><br><a href='mailto:".$email."'><i class='fa fa-envelope'></i> ".$email."</a>"; ?></td>
<td style="text-transform:capitalize;">P: <?php echo $ProvinceName_Kinya."<br>D: ".$DistrictName."<br>S: ".$SectorName."<br>C: ".$CellName; ?></td>
<td><?php echo $w_comp_name."<br>".$w_comp_email."<br>".$w_comp_phone."<br>TIN: ".$w_comp_tin."<br>Bank: ".$w_comp_account; ?></td>
<td><?php echo $edit; ?></td>
<td><?php echo $decision; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}






if(isset($_GET['Sector_ID_Get']))
{
@$Sector_ID_Get=$_GET['Sector_ID_Get'];
@$SectorName_Get=$_GET['SectorName_Get'];
@$DistrictName_Get=$_GET['DistrictName_Get'];
@$ProvinceName_Get=$_GET['ProvinceName_Get'];

//=========COUNT THE NUMBER
$count_no = $DB_con->prepare("SELECT COUNT(internship_members.member_id) FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_sectors.Sector_ID='".$Sector_ID_Get."'");
try {
$count_no->execute(array());
$row_count_no = $count_no->rowCount();
if ($row_count_no > 0)
{
$count_no_array = $count_no->fetch(PDO::FETCH_ASSOC);
$count_no_final = $count_no_array['COUNT(internship_members.member_id)'];
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
//=========COUNT THE NUMBER END 
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-list-ul'></i> <?php echo @$_GET['SectorName_Get']." &raquo; ".$_GET['DistrictName_Get']." &raquo; ".$_GET['ProvinceName_Get']; ?></span>  <a style='color:#fff; background-color:#06C; border-radius:20px; padding: 0.2% 2% 0.2% 2%; margin-left:2%;'><i class='fa fa-users'></i>  <?php echo $count_no_final; ?> Applicants </a>  </h4>
</div>
<?php
$position_view = $DB_con->prepare("SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_sectors.Sector_ID='".$_GET['Sector_ID_Get']."' ORDER BY internship_position.position_id ASC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>#</th><th>Name</th><th>Address</th><th>Company</th><th>Edit</th><th>Status</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}

if($member_status==1)   { $decision='<a href="admin?deny_member='.$member_id.'"><i class="fa fa-trash"></i> deny</a>';}
else   { $decision='<a href="admin?restore_member='.$member_id.'"><i class="fa fa-refresh"></i> restore</a>';}
$edit='<a href="admin?edit_member='.$member_id.'"><i class="fa fa-edit"></i> edit</a>';
?>
<tr>
<td><?php echo $comp_count."<br>".$edit."<br>".$decision; ?></td>
<td><?php echo $position_name."<br>".$first_name." ".$last_name."<br><a href='tel:".$telephone."'><i class='fa fa-phone'></i> ".$telephone."</a><br><a href='mailto:".$email."'><i class='fa fa-envelope'></i> ".$email."</a>"; ?></td>
<td style="text-transform:capitalize;">P: <?php echo $ProvinceName_Kinya."<br>D: ".$DistrictName."<br>S: ".$SectorName."<br>C: ".$CellName; ?></td>
<td><?php echo $w_comp_name."<br>".$w_comp_email."<br>".$w_comp_phone."<br>TIN: ".$w_comp_tin."<br>Bank: ".$w_comp_account; ?></td>
<td><?php echo $edit; ?></td>
<td><?php echo $decision; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}













//===================================EDIT USER
if(isset($_GET['edit_member']))
{
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-list-ul'></i> UPDATE USER N<sup>o</sup>: <?php echo $_GET['edit_member']; ?></span><br></h4>
</div>
<?php
$position_view = $DB_con->prepare("SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_members.member_id='".$_GET['edit_member']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
$pos = $position_view->fetch(PDO::FETCH_ASSOC);

$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
$CellNamex = $ProvinceName." - ".$pos['DistrictName']." - ".$pos['SectorName']." - ".$pos['CellName'];
?>
<div class="container">
<div class="card-body card-block">
<div class="col col-md-7">
<form action="admin" enctype="multipart/form-data" method="POST" class="form-horizontal">
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-location-arrow"></i></div>
<input type="hidden" name="member_id" value="<?php echo $member_id; ?>">
<select name="cell_id" style="text-transform:capitalize;" class="form-control" required>
<option value="<?php echo $Cell_ID; ?>"> <?php echo $CellNamex; ?></option>
<?php
$stmt_view = $DB_con->prepare("SELECT internship_cells.Cell_ID, internship_cells.CellName, internship_sectors.SectorName, internship_district.DistrictName, internship_province.ProvinceName FROM internship_cells, internship_sectors, internship_district, internship_province WHERE internship_sectors.Sector_ID=internship_cells.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_province.ProvinceID=internship_district.ProvinceID AND internship_cells.Cell_ID!='".$Cell_ID."' ORDER BY internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$Cell_ID = $stmt['Cell_ID'];
$ProvinceName = $stmt['ProvinceName'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
$CellName = $ProvinceName_Kinya." - ".$stmt['DistrictName']." - ".$stmt['SectorName']." - ".$stmt['CellName'];
echo '<option value="'.$Cell_ID.'">'.$CellName.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-anchor"></i></div>
<select name="position_id" class="form-control" required>
<option value="<?php echo $position_id; ?>"> <?php echo $position_name; ?></option>
<?php
$stmt_view = $DB_con->prepare("SELECT internship_position.position_id, internship_position.position_name FROM internship_position WHERE internship_position.position_id!='".$position_id."' ORDER BY internship_position.position_name ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$position_id = $stmt['position_id'];
$position_name = $stmt['position_name'];
echo '<option value="'.$position_id.'">'.$position_name.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-bar-chart-o"></i></div>
<select name="company_id" class="form-control" required>
<option value="<?php echo $w_comp_id; ?>"> <?php echo $w_comp_name; ?></option>
<?php
$stmt_view = $DB_con->prepare("SELECT internship_company.w_comp_id, internship_company.w_comp_name FROM internship_company WHERE internship_company.w_comp_id!='".$w_comp_id."' ORDER BY internship_company.w_comp_name ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$w_comp_id = $stmt['w_comp_id'];
$w_comp_name = $stmt['w_comp_name'];
echo '<option value="'.$w_comp_id.'">'.$w_comp_name.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="first_name" value="<?php echo $first_name; ?>" pattern="[A-Z']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="last_name" value="<?php echo $last_name; ?>" pattern="[A-Z a-z ']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
<input type="text" name="telephone" value="<?php echo $telephone; ?>" pattern="[+0-9]+" maxlength="13" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-envelope"></i></div>
<input type="email" name="email" value="<?php echo $email; ?>" class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="text" name="national_id" value="<?php echo $national_id; ?>" pattern="[0-9]+" maxlength="16" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="password" name="password" value="<?php echo $password; ?>"  class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon">
<button type="submit" name="save_user_updated" class="btn btn-success btn-sm"><i class="fa fa-upload"></i> Save updated user</button>
</div></div>
</form>
</div>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}








if(isset($_POST['save_user_updated']))
{

$member_id=$_POST['member_id'];
$position_id=$_POST['position_id'];
$company_id=$_POST['company_id'];
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];
$cell_id=$_POST['cell_id'];
$national_id=$_POST['national_id'];
$username=$_POST['email'];
$password=md5($_POST['password']);
$password_not_encrypted=$_POST['password'];

$sql = "UPDATE internship_members SET position_id = :position_id, company_id = :company_id, first_name = :first_name, last_name = :last_name, telephone = :telephone, email = :email, cell_id = :cell_id, national_id = :national_id, username = :username, password = :password  WHERE internship_members.member_id =  :member_id";

$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':member_id', $member_id, PDO::PARAM_INT);
$stmt->bindParam(':position_id', $position_id, PDO::PARAM_INT);
$stmt->bindParam(':company_id', $company_id, PDO::PARAM_INT);
$stmt->bindParam(':first_name', $first_name, PDO::PARAM_INT);
$stmt->bindParam(':last_name', $last_name, PDO::PARAM_INT);
$stmt->bindParam(':telephone', $telephone, PDO::PARAM_INT);
$stmt->bindParam(':email', $email, PDO::PARAM_INT);
$stmt->bindParam(':cell_id', $cell_id, PDO::PARAM_INT);
$stmt->bindParam(':national_id', $national_id, PDO::PARAM_INT);
$stmt->bindParam(':username', $username, PDO::PARAM_INT);
$stmt->bindParam(':password', $password, PDO::PARAM_INT);
$stmt->execute();

$passwordx=$password_not_encrypted;
$fromName="REGISTRATION PROCESS - Ijambo Rishya";
$message="Murakoze ".@$first_name." ".@$last_name.", REGISTRATION PROCESS ibashimiye uko musanzwe mukorana n\'ikigo kikugezaho amazi. Ubu noneho si ngombwa ko utegereza ko baza kukurebera m<sup>3</sup> umuze gukoresha n\'agaciro k\'ayo kuko ubu buryo bubigukorera ako kanya.\n\nMuhinduye umwirondoro wanyu ku wa (".date('l d/m/Y h:i:s A').")\n\n Ijambo banga rishya: ".$passwordx."\n\nUbundi busobanuro \n\n aimegenie@gmail.com\n info@iotpioneerz.com\n\nC wahamagara:\n\n0785384384\n0725892788\n\nWeb: www.iotpioneerz.com";
$send_to_mail=htmlspecialchars($_POST['email']);
$messages=wordwrap($message, 100, "\r\n");
@mail($send_to_mail, $fromName, $messages);

if($stmt) { echo $top_success;  }
else  {  echo $top_failed;  }
}













?>

</div>
<?php //include('include_copyrights.php'); ?>
<?php include('include_js.php'); ?>
</body>
</html>