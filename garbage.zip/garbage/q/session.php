<?php
if(isset($_SESSION['member_id']))
{}
else
{
@session_start();
if(@session_destroy()) // Destroying All Sessions
{
echo '<meta http-equiv="refresh"'.'content="0; URL=index?'.md5("ok").'">';	
}}
?>