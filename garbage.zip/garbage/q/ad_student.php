﻿<style>
*{font-family:Century Gothic;}
</style>

<?php 
include('include_header.php');
include("connection.php");
include("session.php"); 

$claudine="Done_by_IoT_Pioneerz_0785384384";

$start="ad_student?XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&panel_two&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'));

$set="ad_student?XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&settings=CL&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'));

$success='<center><div class="card-body"><div class="alert alert-success" role="alert">
Done<br><img src="images/load-indicator.gif" style="height:auto;"></center>
</div></div><meta http-equiv="refresh"'.'content="1; URL='.$set.'">';
$failed='<center><div class="card-body"><div class="alert alert-danger" role="alert">
Done<br><img src="images/load-indicator.gif" style="height:auto;"></center>
</div></div><meta http-equiv="refresh"'.'content="1; URL='.$set.'">';

$_SESSION['member_id'];
$_SESSION['ProvinceID'];
$_SESSION['DistrictID'];
$_SESSION['Sector_ID'];
$_SESSION['Cell_ID'];
$_SESSION['position_id'];
$_SESSION['w_comp_id'];
$_SESSION['ProvinceName'];
$_SESSION['DistrictName'];
$_SESSION['SectorName'];
$_SESSION['CellName'];
$_SESSION['position_name'];
$_SESSION['w_comp_name'];
$_SESSION['w_comp_tin'];
$_SESSION['w_comp_logo'];
$_SESSION['w_comp_email'];
$_SESSION['w_comp_phone'];
$_SESSION['w_comp_account'];
$_SESSION['w_comp_moto'];
$_SESSION['w_comp_value'];
$_SESSION['w_comp_mission'];
$_SESSION['w_comp_branches'];
$_SESSION['first_name'];
$_SESSION['last_name'];
$_SESSION['telephone'];
$_SESSION['email'];
$_SESSION['national_id'];
$_SESSION['codes'];
$_SESSION['date_Time'];
$_SESSION['username'];
$_SESSION['password'];
$_SESSION['w_comp_status'];
$_SESSION['member_status'];
$_SESSION['member_education_level']
?>



<body class="animsition">
<div class="page-wrapper">
<!-- HEADER MOBILE-->
<header class="header-mobile d-block d-lg-none">
<div class="header-mobile__bar">
<div class="container-fluid">
<div class="header-mobile-inner">
<a class="logo" href="#">
<img src="../img/icon.png" style=" height:60px;" alt="IoT Pioneer" />

</a>
<button class="hamburger hamburger--slider" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</div>
<nav class="navbar-mobile">
<div class="container-fluid">
<ul class="navbar-mobile__list list-unstyled">

<ul class="list-unstyled navbar__list">
<li class="has-sub"><a class="js-arrow" href="<?php echo $start; ?>"><i class="fa fa-user"></i> My profile</a></li>
<li class="has-sub"><a class="js-arrow" href="<?php echo $set; ?>"><i class="fa fa-tags"></i> Internship</a></li>
<li class="has-sub"><a href="logout" onClick="return confirm('Confirm ?')"><i class="fa fa-lock"></i>&nbsp;Logout</a></li>
</ul>
</div>
</nav>
</header>
<!-- END HEADER MOBILE-->

<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
<div class="logo">
<center><a href="#">
<img src="../img/icon.png" style=" height:50px; " alt="IoT Pioneer" /> 
</a></center>
</div>
<div class="menu-sidebar__content js-scrollbar1">
<nav>

<ul class="list-unstyled">
<li class="has-sub"><a class="js-arrow" style="color:#000; margin:10% 0% 0% 3%;" href="<?php echo $start; ?>"><i class="fa fa-user"></i> My profile</a></li>
<li class="has-sub"><a class="js-arrow" style="color:#000; margin:6% 0% 0% 3%;" href="<?php echo $set; ?>"><i class="fa fa-tags"></i> Internship</a></li>
<li class="has-sub"><a href="logout" style="color:#000; margin:6% 0% 0% 3%;" onClick="return confirm('Confirm ?')"><i class="fa fa-lock"></i> Logout</a></li>
</ul>
</nav>
</div>
</aside>
<!-- END MENU SIDEBAR-->

<!-- PAGE CONTAINER-->
<div class="page-container">
<!-- HEADER DESKTOP-->
<header class="header-desktop">
<div class="section__content section__content--p30">
<div class="container-fluid">
<div class="header-wrap">

<h3><center><img src="../img/icon.png" style="width:60px;" /> Internship Application Web Portal System</center></h3>

</div>
</div>
</div>
</header>
<!-- END HEADER DESKTOP-->

<!-- MAIN CONTENT-->
<div class="main-content">
<div class="section__content section__content--p30">
<div class="container-fluid">

<body onload="startTime()">
<div id="txt" style="font-family:Digital-7 Mono; font-size:24px; color:#000;"></div>
</body>

<div class="row">
<div class="col-lg-12">
<div class="card">

</div>











<?php
if(isset($_GET['panel_two']))
{
?>
<div class="card">
<div class="card-body">
<div class="default-tab">
<nav>
<div class="nav nav-tabs" id="nav-tab" role="tablist">

<a class="nav-item nav-link active" id="nav-user-tab" data-toggle="tab" href="#nav-user" role="tab" aria-controls="nav-user"
aria-selected="true"><i class='fa fa-users'></i> Applicants</a>

<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile"
aria-selected="false"><i class='fa fa-user'></i> Profile</a>

<a class="nav-item nav-link" id="nav-company-tab" data-toggle="tab" href="#nav-company" role="tab" aria-controls="nav-company"
aria-selected="false"><i class='fa fa-list'></i> Companies</a>
</div>
</nav>




<div class="tab-content pl-3 pt-2" id="nav-tabContent">

<div class="tab-pane fade show active" id="nav-user" role="tabpanel" aria-labelledby="nav-user-tab"  style='  color:#000;'>
<b>REGISTERED APPLICANTS</b><br><br>

<?php
$position_view = $DB_con->prepare("SELECT garbage_members.member_id, garbage_province.ProvinceID, garbage_district.DistrictID, garbage_sectors.Sector_ID, garbage_cells.Cell_ID, garbage_position.position_id, garbage_company.w_comp_id, garbage_province.ProvinceName, garbage_district.DistrictName, garbage_sectors.SectorName, garbage_cells.CellName, garbage_position.position_name, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status, garbage_members.first_name, garbage_members.last_name, garbage_members.telephone, garbage_members.email, garbage_members.national_id, garbage_members.codes, garbage_members.date_Time, garbage_members.member_status, garbage_members.username, garbage_members.password FROM garbage_members,garbage_sectors, garbage_province, garbage_position, garbage_district, garbage_company, garbage_cells WHERE garbage_position.position_id=garbage_members.position_id AND garbage_members.company_id=garbage_company.w_comp_id AND garbage_members.cell_id=garbage_cells.Cell_ID AND garbage_cells.Sector_ID=garbage_sectors.Sector_ID AND garbage_sectors.District_ID=garbage_district.DistrictID AND garbage_district.ProvinceID=garbage_province.ProvinceID AND garbage_position.position_id=3");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>#</th><th>Name</th><th>Address</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
?>
<tr>
<td><?php echo $comp_count; ?></td>
<td><?php echo $first_name." ".$last_name."<br><a href='tel:".$telephone."'><i class='fa fa-phone'></i> ".$telephone."</a><br><a href='mailto:".$email."'><i class='fa fa-envelope'></i> ".$email."</a>"; ?></td>
<td style="text-transform:capitalize;">P: <?php echo $ProvinceName_Kinya."<br>D: ".$DistrictName."<br>S: ".$SectorName."<br>C: ".$CellName; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>


<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"  style='  color:#000;'>
<b>MY PROFILE </b><br><br>

<?php
$position_view = $DB_con->prepare("SELECT garbage_members.member_id, garbage_province.ProvinceID, garbage_district.DistrictID, garbage_sectors.Sector_ID, garbage_cells.Cell_ID, garbage_position.position_id, garbage_company.w_comp_id, garbage_province.ProvinceName, garbage_district.DistrictName, garbage_sectors.SectorName, garbage_cells.CellName, garbage_position.position_name, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status, garbage_members.first_name, garbage_members.last_name, garbage_members.telephone, garbage_members.email, garbage_members.national_id, garbage_members.codes, garbage_members.date_Time, garbage_members.member_status, garbage_members.username, garbage_members.password FROM garbage_members,garbage_sectors, garbage_province, garbage_position, garbage_district, garbage_company, garbage_cells WHERE garbage_position.position_id=garbage_members.position_id AND garbage_members.company_id=garbage_company.w_comp_id AND garbage_members.cell_id=garbage_cells.Cell_ID AND garbage_cells.Sector_ID=garbage_sectors.Sector_ID AND garbage_sectors.District_ID=garbage_district.DistrictID AND garbage_district.ProvinceID=garbage_province.ProvinceID AND garbage_members.member_id='".$_SESSION['member_id']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>Name</th><th>Address</th><th>Edit</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
$edit='<a href="ad_student?XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&edit_member='.$member_id.'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'&XYTTZ'.md5(date('s')).'"><i class="fa fa-edit"></i> edit</a>';
?>
<tr>
<td><?php echo $first_name." ".$last_name."<br><a href='tel:".$telephone."'><i class='fa fa-phone'></i> ".$telephone."</a><br><a href='mailto:".$email."'><i class='fa fa-envelope'></i> ".$email."</a>"; ?></td>
<td style="text-transform:capitalize;">Province: <?php echo $ProvinceName_Kinya."<br>District: ".$DistrictName."<br>Sector: ".$SectorName."<br>Cell: ".$CellName; ?></td>
<td><?php echo $edit; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>

</div>




<div class="tab-pane fade" id="nav-company" role="tabpanel" aria-labelledby="nav-company-tab"  style='  color:#000;'>
<b>COMPANIES </b><br><br>

<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company ORDER BY garbage_company.w_comp_name DESC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>Name</th><th>Contact</th><th>Branches</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo']." style='height:50px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];
?>
<tr>
<td><?php echo $w_comp_name."<br>".$w_comp_logo; ?></td>
<td><?php echo $w_comp_email."<br>".$w_comp_phone."<br>TIN: ".$w_comp_tin."<br>Bank: ".$w_comp_account; ?></td>
<td><?php echo $w_comp_branches; ?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>



</div>
</div>
</div>
</div>
<?php
}










if(isset($_GET['settings']))
{
?>
<div class="card">
<div class="card-body">
<div class="default-tab">
<nav>
<div class="nav nav-tabs" id="nav-tab" role="tablist">

<a class="nav-item nav-link active" id="nav-internship-tab" data-toggle="tab" href="#nav-internship" role="tab" aria-controls="nav-internship"
aria-selected="true"><i class='fa fa-book'></i> Internship</a>

<a class="nav-item nav-link" id="nav-applications-tab" data-toggle="tab" href="#nav-applications" role="tab" aria-controls="nav-applications"
aria-selected="false"><i class='fa fa-tags'></i> Your applications</a>

</div>
</nav>




<div class="tab-content pl-3 pt-2" id="nav-tabContent">

<div class="tab-pane fade show active" id="nav-internship" role="tabpanel" aria-labelledby="nav-internship-tab"  style='  color:#000;'>
<br><b>AVAILABLE INTERNSHIP</b><br><hr>

<div style="float:left; width:100%; background-color:#FFF; height:auto; color:#000; font-size:18px;">
<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_document.garbage_id, garbage_document.garbage_doc, garbage_document.garbage_description, garbage_document.garbage_date, garbage_document.garbage_status, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company, garbage_document WHERE garbage_company.w_comp_id=garbage_document.garbage_company_id ORDER BY garbage_document.garbage_id DESC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
$count=0;
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$count++;
$garbage_id = $pos['garbage_id'];
$garbage_doc = "<img src=".$pos['garbage_doc'].">";
$garbage_doc_file = $pos['garbage_doc'];
$garbage_description = nl2br($pos['garbage_description']);
$garbage_date = $pos['garbage_date'];
$garbage_status = $pos['garbage_status'];

$w_comp_id = $pos['w_comp_id'];
$w_comp_name = strtoupper($pos['w_comp_name']);
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];

$edit="<a href='ad_student?XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&apply_internship=".$garbage_id."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&login_now&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."&XYTTZ".md5(date('s'))."' style='color:#fff; background-color:#006699; float:left; padding:0% 5% 0% 5%; margin-top:1%; border-radius:100px; font-weight:bold; font-size:18px;'><i class='fa fa-thumbs-up' style='color:#fff; font-weight:normal; font-size:18px;'></i> Apply here</a>";
?>

<?php echo "<b style='color:#fff; background-color:#006699; padding:1% 4% 1% 4%;  margin-bottom:5%; border-radius:100px; font-size:16px;'>Internship N<sup><u>o</u></sup>: ".$count."</b><br><b style='color:#006699; font-size:16px;'>Company: ".$w_comp_name."<br>Phone: ".$w_comp_phone."<br>Email: ".$w_comp_email."<br>Branches: ".$w_comp_branches."<br>Tin: ".$w_comp_tin."<br>Account: ".$w_comp_account; ?></b><br><br>
<?php echo $garbage_description."<br><br><i style='color:#006699; font-size:14px;'>".$garbage_date; ?></i><br>
<a href="<?php echo $garbage_doc_file; ?>" target="_blank" style="color:#006699; font-weight:bold; font-size:18px;"><br><i class='fa fa-download' style="color:#006699; font-weight:bold; font-size:14px;"></i> Download file</a><br><?php echo $edit; ?><br>
<div style='background-color:#006699; width:100%; float:left; height:2px; margin:3% 0% 3% 0%;'></div>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>

</div>


<div class="tab-pane fade" id="nav-applications" role="tabpanel" aria-labelledby="nav-applications-tab"  style='  color:#000;'>
<br><b>YOUR APPLICATIONS </b><br><br>

<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_document.garbage_id, garbage_members.member_id, garbage_members.first_name, garbage_members.last_name, garbage_members.telephone, garbage_members.email, garbage_members.member_education_level, garbage_members.national_id, garbage_document.garbage_doc, garbage_document.garbage_description, garbage_document.garbage_date, garbage_document.garbage_status, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status, intership_application.application_id, intership_application.application_comment, intership_application.application_answer, intership_application.application_status, intership_application.application_date FROM garbage_company, garbage_document, intership_application, garbage_members WHERE garbage_company.w_comp_id=garbage_document.garbage_company_id AND intership_application.application_garbage_id=garbage_document.garbage_id AND garbage_members.member_id='".$_SESSION['member_id']."' AND garbage_members.member_id=intership_application.application_user_id ORDER BY intership_application.application_id DESC");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
?>
<div class="bs-example4" data-example-id="simple-responsive-table">
<div class="table-responsive"  >
<table class="table  table-borderless table-striped table-earning" width="100%">
<thead><tr><th>#</th><th colspan="4">Observations</th></tr></thead>
<tbody>
<?php
$comp_count=0;
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$comp_count++;
$w_comp_id = $pos['w_comp_id'];
$application_id = $pos['application_id'];
$member_id = $pos['member_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];
$application_comment = nl2br($pos['application_comment']);
$application_answer = nl2br($pos['application_answer']);
$application_date = $pos['application_date'];
$application_status = $pos['application_status'];
$name = $pos['first_name']." ".$pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$member_education_level = $pos['member_education_level'];

if($application_status==0) { $confirm='<b style="color:#006699;"><i class="fa fa-comments"></i> waiting...</b>'; }
else if($application_status==1) { $confirm='<b style="color:green;"><i class="fa fa-check"></i> accepted</b>'; }
else  { $confirm='<b style="color:#F00;"><i class="fa fa-times"></i> rejected</b>'; }

?>
<tr>
<td><?php echo $comp_count; ?></td>
<td><?php echo $name."<br>".$telephone."<br>".$email."<br>".$national_id; ?></td>
<td><?php echo $application_comment."<br><hr><u><b style='color:#006699;'>Answer: </u>".$application_answer; ?></b></td>
<td><a href=""><?php echo $member_education_level."<br>".$confirm; ?></a></td>
</tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>


</div>
</div>
</div>
</div>
<?php
}






//===================================EDIT USER
if(isset($_GET['apply_internship']))
{
if($_SESSION['member_education_level']=='') { $education='Education Level NOT UPDATED';}
else { $education=$_SESSION['member_education_level'];}	
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-list-ul'></i> APPLYING PROCESS OF  <b><?php echo $_SESSION['first_name']." ".$_SESSION['last_name']; ?></b></span><br></h4>
</div>

<div class="container">
<div class="card-body card-block">
<div class="col col-md-7">
<form action="ad_student" enctype="multipart/form-data" method="POST" class="form-horizontal">
<input type="hidden" name="apply_internship" value="<?php echo $_GET['apply_internship']; ?>">
<input type="hidden" name="member_id" value="<?php echo $_SESSION['member_id']; ?>">

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" value="<?php echo $_SESSION['first_name']." ".$_SESSION['last_name']; ?>" readonly class="form-control">
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
<input type="text" value="<?php echo $_SESSION['telephone']; ?>" readonly class="form-control">
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-envelope"></i></div>
<input type="text" value="<?php echo $_SESSION['email']; ?>" readonly class="form-control">
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-book"></i></div>
<input type="text" name="education" value="<?php echo $education; ?>" class="form-control">
</div></div>

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-anchor"></i></div>
<textarea name="comment" value="<?php echo $email; ?>" placeholder="Your comment..." class="form-control"></textarea>
</div></div>


<div class="row form-group"><div class="input-group"><div class="input-group-addon">
<button type="submit" name="save_application" class="btn btn-success btn-sm"><i class="fa fa-upload"></i> Accept application <?php echo $_SESSION['first_name']; ?></button>
</div></div>
</form>
</div>
</div>
</div>
<?php
}




//===================================SAVE APPLICATION
if(isset($_POST['save_application']))
{
$application_user_id=$_POST['member_id'];
$application_garbage_id=$_POST['apply_internship'];
$application_comment=$_POST['comment'];
$education=$_POST['education'];
$application_answer="";
$application_status=0;
$application_date=date('l d/m/Y h:i:s A');



$sql_education = "UPDATE garbage_members SET member_education_level = :education WHERE garbage_members.member_id = :application_user_id";
$stmt = $DB_con->prepare($sql_education);
$stmt->bindParam(':application_user_id', $application_user_id, PDO::PARAM_INT);
$stmt->bindParam(':education', $education, PDO::PARAM_INT);
$stmt->execute();



$save_internship = $DB_con->prepare("INSERT INTO intership_application (application_id, application_user_id, application_garbage_id, application_comment, application_answer, application_status, application_date)  VALUES (?,?,?,?,?,?,?)");  
$save_internship->execute(array('',$application_user_id,$application_garbage_id,$application_comment,$application_answer,$application_status,$application_date));
if($save_internship) { echo $success;  }
else  {  echo $failed;  }
}

//===================================EDIT USER
if(isset($_GET['edit_member']))
{
?>
<div class="card-header">
<h4 style='font-weight:normal;'>
<span style='font-weight:normal;color:#06C; text-transform:capitalize;'>  <i class='fa fa-list-ul'></i> UPDATE <b><?php echo $_SESSION['first_name']." ".$_SESSION['last_name']; ?></b></span><br></h4>
</div>
<?php
$position_view = $DB_con->prepare("SELECT garbage_members.member_id, garbage_province.ProvinceID, garbage_district.DistrictID, garbage_sectors.Sector_ID, garbage_cells.Cell_ID, garbage_position.position_id, garbage_company.w_comp_id, garbage_province.ProvinceName, garbage_district.DistrictName, garbage_sectors.SectorName, garbage_cells.CellName, garbage_position.position_name, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status, garbage_members.first_name, garbage_members.last_name, garbage_members.telephone, garbage_members.email, garbage_members.national_id, garbage_members.codes, garbage_members.date_Time, garbage_members.member_status, garbage_members.username, garbage_members.password FROM garbage_members,garbage_sectors, garbage_province, garbage_position, garbage_district, garbage_company, garbage_cells WHERE garbage_position.position_id=garbage_members.position_id AND garbage_members.company_id=garbage_company.w_comp_id AND garbage_members.cell_id=garbage_cells.Cell_ID AND garbage_cells.Sector_ID=garbage_sectors.Sector_ID AND garbage_sectors.District_ID=garbage_district.DistrictID AND garbage_district.ProvinceID=garbage_province.ProvinceID AND garbage_members.member_id='".$_GET['edit_member']."'");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
$pos = $position_view->fetch(PDO::FETCH_ASSOC);

$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
$CellNamex = $ProvinceName." - ".$pos['DistrictName']." - ".$pos['SectorName']." - ".$pos['CellName'];
?>
<div class="container">
<div class="card-body card-block">
<div class="col col-md-7">
<form action="ad_student" enctype="multipart/form-data" method="POST" class="form-horizontal">
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-location-arrow"></i></div>
<input type="hidden" name="member_id" value="<?php echo $member_id; ?>">
<select name="cell_id" style="text-transform:capitalize;" class="form-control" required>
<option value="<?php echo $Cell_ID; ?>"> <?php echo $CellNamex; ?></option>
<?php
$stmt_view = $DB_con->prepare("SELECT garbage_cells.Cell_ID, garbage_cells.CellName, garbage_sectors.SectorName, garbage_district.DistrictName, garbage_province.ProvinceName FROM garbage_cells, garbage_sectors, garbage_district, garbage_province WHERE garbage_sectors.Sector_ID=garbage_cells.Sector_ID AND garbage_sectors.District_ID=garbage_district.DistrictID AND garbage_province.ProvinceID=garbage_district.ProvinceID AND garbage_cells.Cell_ID!='".$Cell_ID."' ORDER BY garbage_province.ProvinceName, garbage_district.DistrictName, garbage_sectors.SectorName, garbage_cells.CellName ASC");
try {
$stmt_view->execute(array());
$row_stmt = $stmt_view->rowCount();
if ($row_stmt > 0)
{
while($stmt = $stmt_view->fetch(PDO::FETCH_ASSOC))
{
$Cell_ID = $stmt['Cell_ID'];
$ProvinceName = $stmt['ProvinceName'];
if($ProvinceName=='Iburengerazuba') {$ProvinceName_Kinya='Western';}
if($ProvinceName=='Iburasirazuba') {$ProvinceName_Kinya='Eastern';}
if($ProvinceName=='Amajyepfo') {$ProvinceName_Kinya='Southern';}
if($ProvinceName=='Amajyaruguru') {$ProvinceName_Kinya='Northern';}
if($ProvinceName=='Umujyi wa Kigali') {$ProvinceName_Kinya='Kigali City';}
$CellName = $ProvinceName_Kinya." - ".$stmt['DistrictName']." - ".$stmt['SectorName']." - ".$stmt['CellName'];
echo '<option value="'.$Cell_ID.'">'.$CellName.'</option>';
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</select>
</div></div>
<input type="hidden" name="position_id" value="<?php echo $_SESSION['position_id']; ?>">
<input type="hidden" name="company_id" value="<?php echo $_SESSION['w_comp_id']; ?>">

<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="first_name" value="<?php echo $first_name; ?>" pattern="[A-Z']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="last_name" value="<?php echo $last_name; ?>" pattern="[A-Z a-z ']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
<input type="text" name="telephone" value="<?php echo $telephone; ?>" pattern="[+0-9]+" maxlength="13" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-envelope"></i></div>
<input type="email" name="email" value="<?php echo $email; ?>" class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="text" name="national_id" value="<?php echo $national_id; ?>" pattern="[0-9]+" maxlength="16" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="password" name="password" value="<?php echo $password; ?>"  class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon">
<button type="submit" name="save_user_updated" class="btn btn-success btn-sm"><i class="fa fa-upload"></i> Save updated of <?php echo $_SESSION['first_name']; ?></button>
</div></div>
</form>
</div>
</div>
</div>
<?php
}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
}








if(isset($_POST['save_user_updated']))
{

$member_id=$_POST['member_id'];
$position_id=$_POST['position_id'];
$company_id=$_POST['company_id'];
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];
$cell_id=$_POST['cell_id'];
$national_id=$_POST['national_id'];
$username=$_POST['email'];
$password=md5($_POST['password']);
$password_not_encrypted=$_POST['password'];

$sql = "UPDATE garbage_members SET position_id = :position_id, company_id = :company_id, first_name = :first_name, last_name = :last_name, telephone = :telephone, email = :email, cell_id = :cell_id, national_id = :national_id, username = :username, password = :password  WHERE garbage_members.member_id =  :member_id";

$stmt = $DB_con->prepare($sql);
$stmt->bindParam(':member_id', $member_id, PDO::PARAM_INT);
$stmt->bindParam(':position_id', $position_id, PDO::PARAM_INT);
$stmt->bindParam(':company_id', $company_id, PDO::PARAM_INT);
$stmt->bindParam(':first_name', $first_name, PDO::PARAM_INT);
$stmt->bindParam(':last_name', $last_name, PDO::PARAM_INT);
$stmt->bindParam(':telephone', $telephone, PDO::PARAM_INT);
$stmt->bindParam(':email', $email, PDO::PARAM_INT);
$stmt->bindParam(':cell_id', $cell_id, PDO::PARAM_INT);
$stmt->bindParam(':national_id', $national_id, PDO::PARAM_INT);
$stmt->bindParam(':username', $username, PDO::PARAM_INT);
$stmt->bindParam(':password', $password, PDO::PARAM_INT);
$stmt->execute();

$passwordx=$password_not_encrypted;
$fromName="REGISTRATION PROCESS - Ijambo Rishya";
$message="Thanks ".@$first_name." ".@$last_name.", REGISTRATION PROCESS\n\nDone on (".date('l d/m/Y h:i:s A').")\n\nNew password: ".$passwordx."\n\nOther info, contact: \n\n faina@gmail.com\nWeb: www.garbage.rw";
$send_to_mail=htmlspecialchars($_POST['email']);
$messages=wordwrap($message, 100, "\r\n");
@mail($send_to_mail, $fromName, $messages);

if($stmt) { echo $success;  }
else  {  echo $failed;  }
}







?>

</div>
<?php //include('include_copyrights.php'); ?>
<?php include('include_js.php'); ?>
</body>
</html>