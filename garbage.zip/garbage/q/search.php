﻿<?php
//$link = mysqli_connect("localhost", "iotpioneerz_mifopioneerz", "withgod20202020", "iotpioneerz_iot");
$link = mysqli_connect("localhost", "root", "", "internship_db");

$aime="Prepared by NDABAHARIYE Jean Aime - 0785384384";
if($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}

if(isset($_REQUEST["term"])){
$sql = "SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_members.first_name LIKE '%".$_REQUEST["term"]."%'";

if($stmt = mysqli_prepare($link, $sql)){
@mysqli_stmt_bind_param($stmt, $param_term);
$param_term = $_REQUEST["term"] . '%';
if(mysqli_stmt_execute($stmt)){
$result = mysqli_stmt_get_result($stmt);
if(mysqli_num_rows($result) > 0){
$comp_count=0;
while($pos = mysqli_fetch_array($result, MYSQLI_ASSOC))
{
$comp_count++;
$member_id = $pos['member_id'];
$ProvinceID = $pos['ProvinceID'];
$DistrictID = $pos['DistrictID'];
$Sector_ID = $pos['Sector_ID'];
$Cell_ID = $pos['Cell_ID'];
$position_id = $pos['position_id'];
$w_comp_id = $pos['w_comp_id'];
$ProvinceName = $pos['ProvinceName'];
$DistrictName = $pos['DistrictName'];
$SectorName = $pos['SectorName'];
$CellName = $pos['CellName'];
$position_name = $pos['position_name'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src=".$pos['w_comp_logo'].">";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$first_name = $pos['first_name'];
$last_name = $pos['last_name'];
$telephone = $pos['telephone'];
$email = $pos['email'];
$national_id = $pos['national_id'];
$codes = $pos['codes'];
$date_Time = $pos['date_Time'];
$username = $pos['username'];
$password = $pos['password'];
$w_comp_status = $pos['w_comp_status'];
$member_status = $pos['member_status'];
$edit='<a href="admin?edit_member='.$member_id.'" style="color:#09f;"><i class="fa fa-edit"></i> edit '.$first_name.'</a>';

$all_details=$comp_count.". ".$first_name." ".$last_name." (".$position_name.")<br>".$telephone." &raquo; ".$email."<br>".$ProvinceName." &raquo; ".$DistrictName." &raquo; ".$SectorName." &raquo; ".$CellName."<br>".$edit;

echo "<p>".$all_details."</p>";
}} 
else
{
echo "<p>No matches found</p>";
}
} else{
echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}


mysqli_stmt_close($stmt);
}
mysqli_close($link);
?>