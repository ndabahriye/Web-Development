<?php 
include('include_header.php');
include("connection.php");
$aime="Claudine";
?>

<body>
<div class="page-wrapper">
<div class="page-content--bge5">
<div class="container">
<div class="login-wrap">
<div class="login-content">
<div class="login-logo">
<a href="#">
<img src="../img/icon.png" alt="CoolAdmin" style="height:120px; width:auto;">
</a>
</div>
<div class="login-form">
<form action="" method="post">
<div class="form-group">
<label>Type your registered email</label>
<input class="au-input au-input--full" type="email" name="email" placeholder="Email..." autofocus required>
</div>
<button class="au-btn au-btn--block au-btn--green m-b-20" style=" background:linear-gradient(to bottom, #000 5%, #006699 80%);" type="submit"><i class="fa fa-check"></i>   Accept</button>
</form>

<label><a href="index?<?php echo $aime; ?>" style="color:#006699;"><i class="fa fa-unlock"></i> Click here for signin again</a></label>
</div>
</div>
</div>
<center>(Your password will send into your email)
<?php include('include_copyrights.php'); ?>
</center>
</div>
</div>

</div>

<?php include('include_js.php'); ?>
</body>
</html>
<!-- end document-->