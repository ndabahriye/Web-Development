<?php 
include('include_header.php');
include("connection.php");
$aime="Claudine";
$success='<center><div class="alert alert-success" role="alert">
Login Successfull<br><img src="images/load-indicator.gif" style="height:80px;"></div></center>';
$failed='<center><div class="alert alert-danger" role="alert">
Login failed<br><img src="images/load-indicator.gif" style="height:80px;"></div></center>';
?>


<body class="animsition" >
<div class="page-wrapper">
<div class="page-content--bge5">
<div class="container">
<div class="login-wrap">
<div class="login-content">
<div class="login-logo">
<a href="#">
<img src="../img/icon.png" alt="IoT Pioneers" style="height:100px; width:auto;">
</a>
</div>


<?php
$set="ad_company?XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&settings=CL&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'));

$sets="ad_student?XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&settings=CL&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'));

if(isset($_POST['login_now']))
{
$email=$_POST['email'];
$password=md5($_POST['password']);

$stmt = $DB_con->prepare("SELECT internship_members.member_id, internship_province.ProvinceID, internship_district.DistrictID, internship_sectors.Sector_ID, internship_cells.Cell_ID, internship_position.position_id, internship_company.w_comp_id, internship_province.ProvinceName, internship_district.DistrictName, internship_sectors.SectorName, internship_cells.CellName, internship_position.position_name, internship_company.w_comp_name, internship_company.w_comp_tin, internship_company.w_comp_logo, internship_company.w_comp_email, internship_company.w_comp_phone, internship_company.w_comp_account, internship_company.w_comp_moto, internship_company.w_comp_value, internship_company.w_comp_mission, internship_company.w_comp_branches, internship_company.w_comp_status, internship_members.first_name, internship_members.last_name, internship_members.telephone, internship_members.email, internship_members.national_id, internship_members.codes, internship_members.member_education_level, internship_members.date_Time, internship_members.member_status, internship_members.username, internship_members.password FROM internship_members,internship_sectors, internship_province, internship_position, internship_district, internship_company, internship_cells WHERE internship_position.position_id=internship_members.position_id AND internship_members.company_id=internship_company.w_comp_id AND internship_members.cell_id=internship_cells.Cell_ID AND internship_cells.Sector_ID=internship_sectors.Sector_ID AND internship_sectors.District_ID=internship_district.DistrictID AND internship_district.ProvinceID=internship_province.ProvinceID AND internship_members.username='".$email."' AND internship_members.password='".$password."'");
try {
$stmt->execute(array());
$row_count = $stmt->rowCount();
if ($row_count > 0)
{
$pos = $stmt->fetch(PDO::FETCH_ASSOC);

$_SESSION['member_id'] = $pos['member_id'];
$_SESSION['ProvinceID'] = $pos['ProvinceID'];
$_SESSION['DistrictID'] = $pos['DistrictID'];
$_SESSION['Sector_ID'] = $pos['Sector_ID'];
$_SESSION['Cell_ID'] = $pos['Cell_ID'];
$_SESSION['position_id'] = $pos['position_id'];
$_SESSION['w_comp_id'] = $pos['w_comp_id'];
$_SESSION['ProvinceName'] = $pos['ProvinceName'];
$_SESSION['DistrictName'] = $pos['DistrictName'];
$_SESSION['SectorName'] = $pos['SectorName'];
$_SESSION['CellName'] = $pos['CellName'];
$_SESSION['position_name'] = $pos['position_name'];
$_SESSION['w_comp_name'] = $pos['w_comp_name'];
$_SESSION['w_comp_tin'] = $pos['w_comp_tin'];
$_SESSION['w_comp_logo'] = "<img src=".$pos['w_comp_logo']." style='height:60px;'>";
$_SESSION['w_comp_email'] = $pos['w_comp_email'];
$_SESSION['w_comp_phone'] = $pos['w_comp_phone'];
$_SESSION['w_comp_account'] = $pos['w_comp_account'];
$_SESSION['w_comp_moto'] = nl2br($pos['w_comp_moto']);
$_SESSION['w_comp_value'] = nl2br($pos['w_comp_value']);
$_SESSION['w_comp_mission'] = nl2br($pos['w_comp_mission']);
$_SESSION['w_comp_branches'] = nl2br($pos['w_comp_branches']);
$_SESSION['first_name'] = $pos['first_name'];
$_SESSION['last_name'] = $pos['last_name'];
$_SESSION['telephone'] = $pos['telephone'];
$_SESSION['email'] = $pos['email'];
$_SESSION['national_id'] = $pos['national_id'];
$_SESSION['codes'] = $pos['codes'];
$_SESSION['date_Time'] = $pos['date_Time'];
$_SESSION['username'] = $pos['username'];
$_SESSION['password'] = $pos['password'];
$_SESSION['w_comp_status'] = $pos['w_comp_status'];
$_SESSION['member_status'] = $pos['member_status'];
$_SESSION['member_education_level'] = $pos['member_education_level'];

if($_SESSION['position_id']==1)
{
echo $success;
echo '<meta http-equiv="refresh"'.'content="1; URL=admin?view_users=LIST OF USERS">';
}

if($_SESSION['position_id']==2)
{
echo $success;
echo '<meta http-equiv="refresh"'.'content="1; URL='.$set.'">';
}

if($_SESSION['position_id']==3)
{
echo $success;
echo '<meta http-equiv="refresh"'.'content="1; URL='.$sets.'">';
}

}
else
{
echo $failed;
echo '<meta http-equiv="refresh"'.'content="1; URL=index?login_now">';}
}
catch (PDOException $ex)
{  echo $ex->getMessage();  }
}






if(isset($_POST['save_user']))
{
$position_id=3;
$company_id=1;
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];
$cell_id=2317;
$national_id=$_POST['national_id'];
$codes=date('is');
$date_Time=date('d-m-Y');
$member_status=1;
$username=strtolower($email);
$password=md5('12345');
$username_not_encrypted=strtolower($email);
$password_not_encrypted=12345;

$save_stmt = $DB_con->prepare("INSERT INTO internship_members (member_id, position_id, company_id, first_name, last_name, telephone, email, cell_id, national_id, codes, date_Time, member_status, username, password) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");  
$save_stmt->execute(array('',$position_id,$company_id,$first_name,$last_name,$telephone,$email,$cell_id,$national_id,$codes,$date_Time,$member_status,$username,$password));

$passwordx=$password_not_encrypted;
$usernamex=$username_not_encrypted;
$fromName="REGISTRATION PROCESS";
$message="Welcome ".@$first_name." ".@$last_name.", REGISTRATION PROCESS is well done. Registration date is (".date('l d/m/Y h:i:s A').")\n\n Username: ".$usernamex."\n\n Password: ".$passwordx."\n\nMore details, visit www.internship.rw";
$send_to_mail=htmlspecialchars($_POST['email']);
$messages=wordwrap($message, 100, "\r\n");
@mail($send_to_mail, $fromName, $messages);

echo '<center><div class="card-body"><div class="alert alert-success" role="alert">
Done<br><hr>Username: '.$username_not_encrypted.'<br>Password: '.$password_not_encrypted.'<br><hr><br><img src="images/load-indicator.gif" style="height:80px;"></center><meta http-equiv="refresh"'.'content="5; URL=index?login_now">';
}










if(isset($_GET['registration']))
{
?>
<a href="../index" style="float:right; color:006699;"><i class="fa fa-home"></i> Home</a><br><br>
<div class="form-group" style="padding-bottom:5%;">
<form action="index" enctype="multipart/form-data" method="POST" class="form-horizontal">
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="first_name" autofocus placeholder="First name" pattern="[A-Z']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-user"></i></div>
<input type="text" name="last_name" placeholder="Last name" pattern="[A-Z a-z ']+" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-phone"></i></div>
<input type="text" name="telephone" placeholder="+250 - - - - -" pattern="[+0-9]+" maxlength="13" class="form-control" required>
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-envelope"></i></div>
<input type="email" name="email" placeholder="Email" class="form-control">
</div></div>
<div class="row form-group"><div class="input-group"><div class="input-group-addon"><i class="fa fa-edit"></i></div>
<input type="text" name="national_id" placeholder="National ID No" pattern="[0-9]+" maxlength="16" class="form-control" required>
</div></div>
<button type="submit" name="save_user" class="btn btn-success btn-sm" style="float:left;"><i class="fa fa-save"></i> Save user</button>
<button type="reset" class="btn btn-danger btn-sm" style="float:right;"><i class="fa fa-ban"></i> Cancel</button>
</form>
</div>
<?php
}








if(isset($_GET['login_now']))
{
?>
<div class="login-form">
<form action="index" method="POST" enctype="multipart/form-data">
<div class="form-group">
<input class="au-input au-input--full" type="email" name="email" placeholder="Email" required autofocus>
</div>
<div class="form-group">
<input class="au-input au-input--full" type="password" name="password" placeholder="Password" required>
</div>
<div class="login-checkbox">
</div>
<button class="au-btn au-btn--block au-btn--green m-b-20" style=" background:linear-gradient(to bottom, #000 5%, #006699 80%);" name="login_now" type="submit"><i class="fa fa-key"></i> Login</button>
</form>
<label style="float:left">
<a href="forget_pwd?index?<?php echo $aime; ?>" style="color:#006699;"><i class="fa fa-question"></i> Forget the password ?</a>
</label>

<label style="float:right;">
<a href="../index?<?php echo $aime; ?>" style="color:#006699;"><i class="fa fa-home"></i> Home</a>
</label>

<div class="register-link">

<p style="float:left; width:100%; margin-top:5%;">
<a href="index?registration&<?php echo $aime; ?>" style="color:#006699;"><i class="fa fa-tags"></i> Create account now, if not</a>
</p>
</div>
</div>
<?php
}
?>

</div>
</div>
</div>
</div>
<center>
<?php //include('include_copyrights.php'); ?>
<?php include('include_js.php'); ?>
</center>
</div>
</body>
</html>
<!-- end document-->