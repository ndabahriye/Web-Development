<?php
echo'<h3 style="color:red;"><center> <br>You are fake!!!.<br><br>
<img src="../images/load-indicator.gif"   alt=" Logo" /><br><br>Thanks for your hacking.</center></h3>
<meta http-equiv="refresh"'.'content="3; URL=../details.php?comments">';
?>