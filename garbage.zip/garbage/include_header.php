<?php include('q/connection.php'); ?>

<!DOCTYPE html>
<html lang="en" oncontextmenu="return false">
<head>
<!-- Required meta tags -->
<meta charset="utf-8" />
<meta
name="viewport"
content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
<title>Online Garbage Collection Management System</title>
<link rel="icon" href="img/icon.png" />
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css" />
<!-- animate CSS -->
<link rel="stylesheet" href="css/animate.css" />
<!-- owl carousel CSS -->
<link rel="stylesheet" href="css/owl.carousel.min.css" />
<!-- themify CSS -->
<link rel="stylesheet" href="css/themify-icons.css" />
<!-- flaticon CSS -->
<link rel="stylesheet" href="css/flaticon.css" />
<!-- font awesome CSS -->
<link rel="stylesheet" href="css/magnific-popup.css" />
<!-- swiper CSS -->
<link rel="stylesheet" href="css/slick.css" />
<!-- style CSS -->
<link rel="stylesheet" href="css/style.css" />
</head>

<body>
<!--::header part start::-->
<header class="main_menu home_menu">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-12">
<nav class="navbar navbar-expand-lg navbar-light">
<a class="navbar-brand" href="index"><img src="img/logos.png" alt="logo" class="logo" style="border-radius:100%;" /></a>
<button
class="navbar-toggler"
type="button"
data-toggle="collapse"
data-target="#navbarSupportedContent"
aria-controls="navbarSupportedContent"
aria-expanded="false"
aria-label="Toggle navigation"><span style=" text-align:left;">O.G.C.M.S</span>
<span class="ti-menu"></span>
</button>
<div

class="collapse navbar-collapse main-menu-item justify-content-center"
id="navbarSupportedContent">
<ul class="navbar-nav align-items-center">
<li class="nav-item">
<a class="nav-link" href="index?<?php echo md5(date('is')); ?>&title=HOME"><i class="ti-home"></i> Home</a>
</li>
<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
aria-expanded="false"><i class="ti-direction-alt"></i> Companies</a><div class="dropdown-menu" aria-labelledby="navbarDropdown">

<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company ORDER BY garbage_company.w_comp_id DESC LIMIT 0,5");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = $pos['w_comp_name'];
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='height:50px; border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];
?>
<a class="dropdown-item" href="#"><i class="ti-hand-point-right"></i> <?php echo $w_comp_name; ?></a>
<?php
}}
else{ }
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>
</li>

<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
aria-expanded="false"><i class="ti-user"></i> Clients</a><div class="dropdown-menu" aria-labelledby="navbarDropdown">

<?php
$position_view = $DB_con->prepare("SELECT garbage_company.w_comp_id, garbage_document.garbage_id, garbage_document.garbage_doc, garbage_document.garbage_description, garbage_document.garbage_date, garbage_document.garbage_status, garbage_company.w_comp_name, garbage_company.w_comp_tin, garbage_company.w_comp_logo, garbage_company.w_comp_email, garbage_company.w_comp_phone, garbage_company.w_comp_account, garbage_company.w_comp_moto, garbage_company.w_comp_value, garbage_company.w_comp_mission, garbage_company.w_comp_branches, garbage_company.w_comp_status FROM garbage_company, garbage_document WHERE garbage_company.w_comp_id=garbage_document.garbage_company_id AND garbage_document.garbage_status=1 ORDER BY garbage_document.garbage_id DESC LIMIT 0,5");
try {
$position_view->execute(array());
$row_pos = $position_view->rowCount();
if ($row_pos > 0)
{
while($pos = $position_view->fetch(PDO::FETCH_ASSOC))
{
$garbage_id = $pos['garbage_id'];
$garbage_doc_file = $pos['garbage_doc'];
$garbage_doc = "<img src='q/".$pos['garbage_doc']."' style='border-radius:100px;'>";
$garbage_description = $pos['garbage_description'];
$garbage_date = $pos['garbage_date'];
$garbage_status = $pos['garbage_status'];
$w_comp_id = $pos['w_comp_id'];
$w_comp_name = strtoupper($pos['w_comp_name']);
$w_comp_tin = $pos['w_comp_tin'];
$w_comp_logo = "<img src='q/".$pos['w_comp_logo']."' style='border-radius:100px;'>";
$w_comp_email = $pos['w_comp_email'];
$w_comp_phone = $pos['w_comp_phone'];
$w_comp_account = $pos['w_comp_account'];
$w_comp_moto = nl2br($pos['w_comp_moto']);
$w_comp_value = nl2br($pos['w_comp_value']);
$w_comp_mission = nl2br($pos['w_comp_mission']);
$w_comp_branches = nl2br($pos['w_comp_branches']);
$w_comp_status = $pos['w_comp_status'];

if($w_comp_status==1) 
{ $more='<a class="dropdown-item" href="qx?mx&'.md5(date('is')).'&registration&title=SERVICES"><i class="ti-pin-alt"></i> View more...</a>';}
else
{ $more='';}

$details="qx?XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&d=".$garbage_id."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."&XCVFFRTH_".md5(date('s'))."";

?>
<a class="dropdown-item" href="<?php echo $details; ?>"><i class="ti-pin-alt"></i> Application in <?php echo $w_comp_name; ?></a>
<?php
}
echo $more;
}
else
{
?>
<center><img src="q/images/sacrain.gif"/><br />
<a href="#" style="float:left; margin-bottom:2%; width:100%; color:#F00; font-size:16px; font-weight:bold;"> No internship</a></center>
<?php
}
}
catch (PDOException $ex)
{  $ex->getMessage();  }
?>
</div>
</li>


<li class="nav-item"><a class="nav-link" href="q?<?php echo md5(date('is')); ?>&login_now&title=LOGIN"><i class="ti-key"></i> Login</a></li>
</ul>
</div>
<div class="social_icon d-none d-lg-block">
<a href="#O.G.C.M.S"><i class="ti-facebook"></i></a>
<a href="#O.G.C.M.S"><i class="ti-twitter-alt"></i></a>
<a href="#O.G.C.M.S"><i class="ti-instagram"></i></a>
</div>
</nav>
</div>
</div>
</div>
</header>
<!-- Header part end-->